Source Notes for PICkit(R) 2 Microcontroller Programmer PC Application v2.60.01

Contains Device File V1.61.00 as
\PICkit2V2\PICkit2V2\bin\Release\PK2DeviceFile.dat

This source project can be opened and modified in Microsoft Visual C# Express 2005.
It requires installation of the Microsoft .NET Framework 2.0
