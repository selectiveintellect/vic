namespace PICkit2V2
{
    partial class DialogConfigEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1_15 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox1_0 = new System.Windows.Forms.TextBox();
            this.labelVal1 = new System.Windows.Forms.Label();
            this.labelAdr1 = new System.Windows.Forms.Label();
            this.textBox1_1 = new System.Windows.Forms.TextBox();
            this.labelName1 = new System.Windows.Forms.Label();
            this.textBox1_2 = new System.Windows.Forms.TextBox();
            this.textBox1_11 = new System.Windows.Forms.TextBox();
            this.textBox1_12 = new System.Windows.Forms.TextBox();
            this.textBox1_3 = new System.Windows.Forms.TextBox();
            this.textBox1_10 = new System.Windows.Forms.TextBox();
            this.textBox1_13 = new System.Windows.Forms.TextBox();
            this.textBox1_4 = new System.Windows.Forms.TextBox();
            this.textBox1_9 = new System.Windows.Forms.TextBox();
            this.textBox1_14 = new System.Windows.Forms.TextBox();
            this.textBox1_5 = new System.Windows.Forms.TextBox();
            this.textBox1_8 = new System.Windows.Forms.TextBox();
            this.textBox1_7 = new System.Windows.Forms.TextBox();
            this.textBox1_6 = new System.Windows.Forms.TextBox();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxEx = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxUnimpl = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox2_15 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.textBox2_0 = new System.Windows.Forms.TextBox();
            this.labelVal2 = new System.Windows.Forms.Label();
            this.labelAdr2 = new System.Windows.Forms.Label();
            this.textBox2_1 = new System.Windows.Forms.TextBox();
            this.labelName2 = new System.Windows.Forms.Label();
            this.textBox2_2 = new System.Windows.Forms.TextBox();
            this.textBox2_11 = new System.Windows.Forms.TextBox();
            this.textBox2_12 = new System.Windows.Forms.TextBox();
            this.textBox2_3 = new System.Windows.Forms.TextBox();
            this.textBox2_10 = new System.Windows.Forms.TextBox();
            this.textBox2_13 = new System.Windows.Forms.TextBox();
            this.textBox2_4 = new System.Windows.Forms.TextBox();
            this.textBox2_9 = new System.Windows.Forms.TextBox();
            this.textBox2_14 = new System.Windows.Forms.TextBox();
            this.textBox2_5 = new System.Windows.Forms.TextBox();
            this.textBox2_8 = new System.Windows.Forms.TextBox();
            this.textBox2_7 = new System.Windows.Forms.TextBox();
            this.textBox2_6 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox3_15 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.textBox3_0 = new System.Windows.Forms.TextBox();
            this.labelVal3 = new System.Windows.Forms.Label();
            this.labelAdr3 = new System.Windows.Forms.Label();
            this.textBox3_1 = new System.Windows.Forms.TextBox();
            this.labelName3 = new System.Windows.Forms.Label();
            this.textBox3_2 = new System.Windows.Forms.TextBox();
            this.textBox3_11 = new System.Windows.Forms.TextBox();
            this.textBox3_12 = new System.Windows.Forms.TextBox();
            this.textBox3_3 = new System.Windows.Forms.TextBox();
            this.textBox3_10 = new System.Windows.Forms.TextBox();
            this.textBox3_13 = new System.Windows.Forms.TextBox();
            this.textBox3_4 = new System.Windows.Forms.TextBox();
            this.textBox3_9 = new System.Windows.Forms.TextBox();
            this.textBox3_14 = new System.Windows.Forms.TextBox();
            this.textBox3_5 = new System.Windows.Forms.TextBox();
            this.textBox3_8 = new System.Windows.Forms.TextBox();
            this.textBox3_7 = new System.Windows.Forms.TextBox();
            this.textBox3_6 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.textBox4_15 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.textBox4_0 = new System.Windows.Forms.TextBox();
            this.labelVal4 = new System.Windows.Forms.Label();
            this.labelAdr4 = new System.Windows.Forms.Label();
            this.textBox4_1 = new System.Windows.Forms.TextBox();
            this.labelName4 = new System.Windows.Forms.Label();
            this.textBox4_2 = new System.Windows.Forms.TextBox();
            this.textBox4_11 = new System.Windows.Forms.TextBox();
            this.textBox4_12 = new System.Windows.Forms.TextBox();
            this.textBox4_3 = new System.Windows.Forms.TextBox();
            this.textBox4_10 = new System.Windows.Forms.TextBox();
            this.textBox4_13 = new System.Windows.Forms.TextBox();
            this.textBox4_4 = new System.Windows.Forms.TextBox();
            this.textBox4_9 = new System.Windows.Forms.TextBox();
            this.textBox4_14 = new System.Windows.Forms.TextBox();
            this.textBox4_5 = new System.Windows.Forms.TextBox();
            this.textBox4_8 = new System.Windows.Forms.TextBox();
            this.textBox4_7 = new System.Windows.Forms.TextBox();
            this.textBox4_6 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBox5_15 = new System.Windows.Forms.TextBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.textBox5_0 = new System.Windows.Forms.TextBox();
            this.labelVal5 = new System.Windows.Forms.Label();
            this.labelAdr5 = new System.Windows.Forms.Label();
            this.textBox5_1 = new System.Windows.Forms.TextBox();
            this.labelName5 = new System.Windows.Forms.Label();
            this.textBox5_2 = new System.Windows.Forms.TextBox();
            this.textBox5_11 = new System.Windows.Forms.TextBox();
            this.textBox5_12 = new System.Windows.Forms.TextBox();
            this.textBox5_3 = new System.Windows.Forms.TextBox();
            this.textBox5_10 = new System.Windows.Forms.TextBox();
            this.textBox5_13 = new System.Windows.Forms.TextBox();
            this.textBox5_4 = new System.Windows.Forms.TextBox();
            this.textBox5_9 = new System.Windows.Forms.TextBox();
            this.textBox5_14 = new System.Windows.Forms.TextBox();
            this.textBox5_5 = new System.Windows.Forms.TextBox();
            this.textBox5_8 = new System.Windows.Forms.TextBox();
            this.textBox5_7 = new System.Windows.Forms.TextBox();
            this.textBox5_6 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox6_15 = new System.Windows.Forms.TextBox();
            this.label91 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.textBox6_0 = new System.Windows.Forms.TextBox();
            this.labelVal6 = new System.Windows.Forms.Label();
            this.labelAdr6 = new System.Windows.Forms.Label();
            this.textBox6_1 = new System.Windows.Forms.TextBox();
            this.labelName6 = new System.Windows.Forms.Label();
            this.textBox6_2 = new System.Windows.Forms.TextBox();
            this.textBox6_11 = new System.Windows.Forms.TextBox();
            this.textBox6_12 = new System.Windows.Forms.TextBox();
            this.textBox6_3 = new System.Windows.Forms.TextBox();
            this.textBox6_10 = new System.Windows.Forms.TextBox();
            this.textBox6_13 = new System.Windows.Forms.TextBox();
            this.textBox6_4 = new System.Windows.Forms.TextBox();
            this.textBox6_9 = new System.Windows.Forms.TextBox();
            this.textBox6_14 = new System.Windows.Forms.TextBox();
            this.textBox6_5 = new System.Windows.Forms.TextBox();
            this.textBox6_8 = new System.Windows.Forms.TextBox();
            this.textBox6_7 = new System.Windows.Forms.TextBox();
            this.textBox6_6 = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBox7_15 = new System.Windows.Forms.TextBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.textBox7_0 = new System.Windows.Forms.TextBox();
            this.labelVal7 = new System.Windows.Forms.Label();
            this.labelAdr7 = new System.Windows.Forms.Label();
            this.textBox7_1 = new System.Windows.Forms.TextBox();
            this.labelName7 = new System.Windows.Forms.Label();
            this.textBox7_2 = new System.Windows.Forms.TextBox();
            this.textBox7_11 = new System.Windows.Forms.TextBox();
            this.textBox7_12 = new System.Windows.Forms.TextBox();
            this.textBox7_3 = new System.Windows.Forms.TextBox();
            this.textBox7_10 = new System.Windows.Forms.TextBox();
            this.textBox7_13 = new System.Windows.Forms.TextBox();
            this.textBox7_4 = new System.Windows.Forms.TextBox();
            this.textBox7_9 = new System.Windows.Forms.TextBox();
            this.textBox7_14 = new System.Windows.Forms.TextBox();
            this.textBox7_5 = new System.Windows.Forms.TextBox();
            this.textBox7_8 = new System.Windows.Forms.TextBox();
            this.textBox7_7 = new System.Windows.Forms.TextBox();
            this.textBox7_6 = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBox8_15 = new System.Windows.Forms.TextBox();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.textBox8_0 = new System.Windows.Forms.TextBox();
            this.labelVal8 = new System.Windows.Forms.Label();
            this.labelAdr8 = new System.Windows.Forms.Label();
            this.textBox8_1 = new System.Windows.Forms.TextBox();
            this.labelName8 = new System.Windows.Forms.Label();
            this.textBox8_2 = new System.Windows.Forms.TextBox();
            this.textBox8_11 = new System.Windows.Forms.TextBox();
            this.textBox8_12 = new System.Windows.Forms.TextBox();
            this.textBox8_3 = new System.Windows.Forms.TextBox();
            this.textBox8_10 = new System.Windows.Forms.TextBox();
            this.textBox8_13 = new System.Windows.Forms.TextBox();
            this.textBox8_4 = new System.Windows.Forms.TextBox();
            this.textBox8_9 = new System.Windows.Forms.TextBox();
            this.textBox8_14 = new System.Windows.Forms.TextBox();
            this.textBox8_5 = new System.Windows.Forms.TextBox();
            this.textBox8_8 = new System.Windows.Forms.TextBox();
            this.textBox8_7 = new System.Windows.Forms.TextBox();
            this.textBox8_6 = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.textBox9_15 = new System.Windows.Forms.TextBox();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.textBox9_0 = new System.Windows.Forms.TextBox();
            this.labelVal9 = new System.Windows.Forms.Label();
            this.labelAdr9 = new System.Windows.Forms.Label();
            this.textBox9_1 = new System.Windows.Forms.TextBox();
            this.labelName9 = new System.Windows.Forms.Label();
            this.textBox9_2 = new System.Windows.Forms.TextBox();
            this.textBox9_11 = new System.Windows.Forms.TextBox();
            this.textBox9_12 = new System.Windows.Forms.TextBox();
            this.textBox9_3 = new System.Windows.Forms.TextBox();
            this.textBox9_10 = new System.Windows.Forms.TextBox();
            this.textBox9_13 = new System.Windows.Forms.TextBox();
            this.textBox9_4 = new System.Windows.Forms.TextBox();
            this.textBox9_9 = new System.Windows.Forms.TextBox();
            this.textBox9_14 = new System.Windows.Forms.TextBox();
            this.textBox9_5 = new System.Windows.Forms.TextBox();
            this.textBox9_8 = new System.Windows.Forms.TextBox();
            this.textBox9_7 = new System.Windows.Forms.TextBox();
            this.textBox9_6 = new System.Windows.Forms.TextBox();
            this.label155 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox1_15);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.textBox1_0);
            this.panel1.Controls.Add(this.labelVal1);
            this.panel1.Controls.Add(this.labelAdr1);
            this.panel1.Controls.Add(this.textBox1_1);
            this.panel1.Controls.Add(this.labelName1);
            this.panel1.Controls.Add(this.textBox1_2);
            this.panel1.Controls.Add(this.textBox1_11);
            this.panel1.Controls.Add(this.textBox1_12);
            this.panel1.Controls.Add(this.textBox1_3);
            this.panel1.Controls.Add(this.textBox1_10);
            this.panel1.Controls.Add(this.textBox1_13);
            this.panel1.Controls.Add(this.textBox1_4);
            this.panel1.Controls.Add(this.textBox1_9);
            this.panel1.Controls.Add(this.textBox1_14);
            this.panel1.Controls.Add(this.textBox1_5);
            this.panel1.Controls.Add(this.textBox1_8);
            this.panel1.Controls.Add(this.textBox1_7);
            this.panel1.Controls.Add(this.textBox1_6);
            this.panel1.Location = new System.Drawing.Point(12, 77);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(648, 46);
            this.panel1.TabIndex = 0;
            // 
            // textBox1_15
            // 
            this.textBox1_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_15.Location = new System.Drawing.Point(237, 22);
            this.textBox1_15.Name = "textBox1_15";
            this.textBox1_15.ReadOnly = true;
            this.textBox1_15.Size = new System.Drawing.Size(18, 20);
            this.textBox1_15.TabIndex = 11;
            this.textBox1_15.Text = "1";
            this.textBox1_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(624, 6);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(13, 13);
            this.label23.TabIndex = 38;
            this.label23.Text = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(600, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(13, 13);
            this.label22.TabIndex = 37;
            this.label22.Text = "1";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(576, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(13, 13);
            this.label21.TabIndex = 36;
            this.label21.Text = "2";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(552, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(13, 13);
            this.label20.TabIndex = 35;
            this.label20.Text = "3";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(520, 6);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(13, 13);
            this.label19.TabIndex = 34;
            this.label19.Text = "4";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(496, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(13, 13);
            this.label18.TabIndex = 33;
            this.label18.Text = "5";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(472, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(13, 13);
            this.label17.TabIndex = 32;
            this.label17.Text = "6";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(448, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 31;
            this.label16.Text = "7";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(415, 6);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "8";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(391, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(13, 13);
            this.label14.TabIndex = 29;
            this.label14.Text = "9";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(364, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(19, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "10";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(340, 6);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(19, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "11";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(308, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(19, 13);
            this.label11.TabIndex = 26;
            this.label11.Text = "12";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(284, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(19, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "13";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(260, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 13);
            this.label9.TabIndex = 24;
            this.label9.Text = "14";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(236, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 13);
            this.label8.TabIndex = 23;
            this.label8.Text = "15";
            // 
            // textBox1_0
            // 
            this.textBox1_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_0.Location = new System.Drawing.Point(622, 22);
            this.textBox1_0.Name = "textBox1_0";
            this.textBox1_0.ReadOnly = true;
            this.textBox1_0.Size = new System.Drawing.Size(18, 20);
            this.textBox1_0.TabIndex = 22;
            this.textBox1_0.Text = "1";
            this.textBox1_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal1
            // 
            this.labelVal1.AutoSize = true;
            this.labelVal1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal1.Location = new System.Drawing.Point(165, 23);
            this.labelVal1.Name = "labelVal1";
            this.labelVal1.Size = new System.Drawing.Size(39, 15);
            this.labelVal1.TabIndex = 7;
            this.labelVal1.Text = "3FFF";
            // 
            // labelAdr1
            // 
            this.labelAdr1.AutoSize = true;
            this.labelAdr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr1.Location = new System.Drawing.Point(88, 23);
            this.labelAdr1.Name = "labelAdr1";
            this.labelAdr1.Size = new System.Drawing.Size(39, 15);
            this.labelAdr1.TabIndex = 1;
            this.labelAdr1.Text = "2007";
            // 
            // textBox1_1
            // 
            this.textBox1_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_1.Location = new System.Drawing.Point(598, 22);
            this.textBox1_1.Name = "textBox1_1";
            this.textBox1_1.ReadOnly = true;
            this.textBox1_1.Size = new System.Drawing.Size(18, 20);
            this.textBox1_1.TabIndex = 21;
            this.textBox1_1.Text = "1";
            this.textBox1_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName1
            // 
            this.labelName1.AutoSize = true;
            this.labelName1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName1.Location = new System.Drawing.Point(-3, 23);
            this.labelName1.Name = "labelName1";
            this.labelName1.Size = new System.Drawing.Size(58, 15);
            this.labelName1.TabIndex = 0;
            this.labelName1.Text = "CONFIG";
            // 
            // textBox1_2
            // 
            this.textBox1_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_2.Location = new System.Drawing.Point(574, 22);
            this.textBox1_2.Name = "textBox1_2";
            this.textBox1_2.ReadOnly = true;
            this.textBox1_2.Size = new System.Drawing.Size(18, 20);
            this.textBox1_2.TabIndex = 20;
            this.textBox1_2.Text = "1";
            this.textBox1_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_11
            // 
            this.textBox1_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_11.Location = new System.Drawing.Point(341, 22);
            this.textBox1_11.Name = "textBox1_11";
            this.textBox1_11.ReadOnly = true;
            this.textBox1_11.Size = new System.Drawing.Size(18, 20);
            this.textBox1_11.TabIndex = 11;
            this.textBox1_11.Text = "1";
            this.textBox1_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_12
            // 
            this.textBox1_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_12.Location = new System.Drawing.Point(309, 22);
            this.textBox1_12.Name = "textBox1_12";
            this.textBox1_12.ReadOnly = true;
            this.textBox1_12.Size = new System.Drawing.Size(18, 20);
            this.textBox1_12.TabIndex = 10;
            this.textBox1_12.Text = "1";
            this.textBox1_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_3
            // 
            this.textBox1_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_3.Location = new System.Drawing.Point(550, 22);
            this.textBox1_3.Name = "textBox1_3";
            this.textBox1_3.ReadOnly = true;
            this.textBox1_3.Size = new System.Drawing.Size(18, 20);
            this.textBox1_3.TabIndex = 19;
            this.textBox1_3.Text = "1";
            this.textBox1_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_10
            // 
            this.textBox1_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_10.Location = new System.Drawing.Point(365, 22);
            this.textBox1_10.Name = "textBox1_10";
            this.textBox1_10.ReadOnly = true;
            this.textBox1_10.Size = new System.Drawing.Size(18, 20);
            this.textBox1_10.TabIndex = 12;
            this.textBox1_10.Text = "1";
            this.textBox1_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_13
            // 
            this.textBox1_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_13.Location = new System.Drawing.Point(285, 22);
            this.textBox1_13.Name = "textBox1_13";
            this.textBox1_13.ReadOnly = true;
            this.textBox1_13.Size = new System.Drawing.Size(18, 20);
            this.textBox1_13.TabIndex = 9;
            this.textBox1_13.Text = "1";
            this.textBox1_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_4
            // 
            this.textBox1_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_4.Location = new System.Drawing.Point(518, 22);
            this.textBox1_4.Name = "textBox1_4";
            this.textBox1_4.ReadOnly = true;
            this.textBox1_4.Size = new System.Drawing.Size(18, 20);
            this.textBox1_4.TabIndex = 18;
            this.textBox1_4.Text = "1";
            this.textBox1_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_9
            // 
            this.textBox1_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_9.Location = new System.Drawing.Point(389, 22);
            this.textBox1_9.Name = "textBox1_9";
            this.textBox1_9.ReadOnly = true;
            this.textBox1_9.Size = new System.Drawing.Size(18, 20);
            this.textBox1_9.TabIndex = 13;
            this.textBox1_9.Text = "1";
            this.textBox1_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_14
            // 
            this.textBox1_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_14.Location = new System.Drawing.Point(261, 22);
            this.textBox1_14.Name = "textBox1_14";
            this.textBox1_14.ReadOnly = true;
            this.textBox1_14.Size = new System.Drawing.Size(18, 20);
            this.textBox1_14.TabIndex = 8;
            this.textBox1_14.Text = "1";
            this.textBox1_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_5
            // 
            this.textBox1_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_5.Location = new System.Drawing.Point(494, 22);
            this.textBox1_5.Name = "textBox1_5";
            this.textBox1_5.ReadOnly = true;
            this.textBox1_5.Size = new System.Drawing.Size(18, 20);
            this.textBox1_5.TabIndex = 17;
            this.textBox1_5.Text = "1";
            this.textBox1_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_8
            // 
            this.textBox1_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_8.Location = new System.Drawing.Point(413, 22);
            this.textBox1_8.Name = "textBox1_8";
            this.textBox1_8.ReadOnly = true;
            this.textBox1_8.Size = new System.Drawing.Size(18, 20);
            this.textBox1_8.TabIndex = 14;
            this.textBox1_8.Text = "1";
            this.textBox1_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_7
            // 
            this.textBox1_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_7.Location = new System.Drawing.Point(446, 22);
            this.textBox1_7.Name = "textBox1_7";
            this.textBox1_7.ReadOnly = true;
            this.textBox1_7.Size = new System.Drawing.Size(18, 20);
            this.textBox1_7.TabIndex = 15;
            this.textBox1_7.Text = "1";
            this.textBox1_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox1_6
            // 
            this.textBox1_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox1_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1_6.Location = new System.Drawing.Point(470, 22);
            this.textBox1_6.Name = "textBox1_6";
            this.textBox1_6.ReadOnly = true;
            this.textBox1_6.Size = new System.Drawing.Size(18, 20);
            this.textBox1_6.TabIndex = 16;
            this.textBox1_6.Text = "1";
            this.textBox1_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.buttonSave.Location = new System.Drawing.Point(502, 523);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(75, 23);
            this.buttonSave.TabIndex = 1;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = true;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.buttonCancel.Location = new System.Drawing.Point(585, 523);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(75, 23);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(100, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Address";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(177, 58);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "Value";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(422, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Bit Edit";
            // 
            // textBoxEx
            // 
            this.textBoxEx.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxEx.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBoxEx.Enabled = false;
            this.textBoxEx.Location = new System.Drawing.Point(172, 25);
            this.textBoxEx.Name = "textBoxEx";
            this.textBoxEx.ReadOnly = true;
            this.textBoxEx.Size = new System.Drawing.Size(18, 20);
            this.textBoxEx.TabIndex = 7;
            this.textBoxEx.Text = "1";
            this.textBoxEx.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(615, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Device Configuration Words may be edited here at the bit level.  Refer to device " +
                "datasheet for specific configuration bit functions.";
            // 
            // textBoxUnimpl
            // 
            this.textBoxUnimpl.BackColor = System.Drawing.SystemColors.Control;
            this.textBoxUnimpl.Cursor = System.Windows.Forms.Cursors.Default;
            this.textBoxUnimpl.Enabled = false;
            this.textBoxUnimpl.Location = new System.Drawing.Point(12, 25);
            this.textBoxUnimpl.Name = "textBoxUnimpl";
            this.textBoxUnimpl.ReadOnly = true;
            this.textBoxUnimpl.Size = new System.Drawing.Size(18, 20);
            this.textBoxUnimpl.TabIndex = 8;
            this.textBoxUnimpl.Text = "-";
            this.textBoxUnimpl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "= Unimplemented bit";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(196, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(200, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "= Configuration bit.  Click to toggle value.";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox2_15);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.label34);
            this.panel2.Controls.Add(this.label35);
            this.panel2.Controls.Add(this.label36);
            this.panel2.Controls.Add(this.label37);
            this.panel2.Controls.Add(this.label38);
            this.panel2.Controls.Add(this.label39);
            this.panel2.Controls.Add(this.textBox2_0);
            this.panel2.Controls.Add(this.labelVal2);
            this.panel2.Controls.Add(this.labelAdr2);
            this.panel2.Controls.Add(this.textBox2_1);
            this.panel2.Controls.Add(this.labelName2);
            this.panel2.Controls.Add(this.textBox2_2);
            this.panel2.Controls.Add(this.textBox2_11);
            this.panel2.Controls.Add(this.textBox2_12);
            this.panel2.Controls.Add(this.textBox2_3);
            this.panel2.Controls.Add(this.textBox2_10);
            this.panel2.Controls.Add(this.textBox2_13);
            this.panel2.Controls.Add(this.textBox2_4);
            this.panel2.Controls.Add(this.textBox2_9);
            this.panel2.Controls.Add(this.textBox2_14);
            this.panel2.Controls.Add(this.textBox2_5);
            this.panel2.Controls.Add(this.textBox2_8);
            this.panel2.Controls.Add(this.textBox2_7);
            this.panel2.Controls.Add(this.textBox2_6);
            this.panel2.Location = new System.Drawing.Point(12, 125);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(648, 46);
            this.panel2.TabIndex = 11;
            // 
            // textBox2_15
            // 
            this.textBox2_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_15.Location = new System.Drawing.Point(237, 22);
            this.textBox2_15.Name = "textBox2_15";
            this.textBox2_15.ReadOnly = true;
            this.textBox2_15.Size = new System.Drawing.Size(18, 20);
            this.textBox2_15.TabIndex = 11;
            this.textBox2_15.Text = "1";
            this.textBox2_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(624, 6);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(13, 13);
            this.label24.TabIndex = 38;
            this.label24.Text = "0";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(600, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(13, 13);
            this.label25.TabIndex = 37;
            this.label25.Text = "1";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(576, 6);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(13, 13);
            this.label26.TabIndex = 36;
            this.label26.Text = "2";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(552, 6);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(13, 13);
            this.label27.TabIndex = 35;
            this.label27.Text = "3";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(520, 6);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(13, 13);
            this.label28.TabIndex = 34;
            this.label28.Text = "4";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(496, 6);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(13, 13);
            this.label29.TabIndex = 33;
            this.label29.Text = "5";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(472, 6);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(13, 13);
            this.label30.TabIndex = 32;
            this.label30.Text = "6";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(448, 6);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(13, 13);
            this.label31.TabIndex = 31;
            this.label31.Text = "7";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(415, 6);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(13, 13);
            this.label32.TabIndex = 30;
            this.label32.Text = "8";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(391, 6);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(13, 13);
            this.label33.TabIndex = 29;
            this.label33.Text = "9";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(364, 6);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(19, 13);
            this.label34.TabIndex = 28;
            this.label34.Text = "10";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(340, 6);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(19, 13);
            this.label35.TabIndex = 27;
            this.label35.Text = "11";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(308, 6);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(19, 13);
            this.label36.TabIndex = 26;
            this.label36.Text = "12";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(284, 6);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(19, 13);
            this.label37.TabIndex = 25;
            this.label37.Text = "13";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(260, 6);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(19, 13);
            this.label38.TabIndex = 24;
            this.label38.Text = "14";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(236, 6);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(19, 13);
            this.label39.TabIndex = 23;
            this.label39.Text = "15";
            // 
            // textBox2_0
            // 
            this.textBox2_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_0.Location = new System.Drawing.Point(622, 22);
            this.textBox2_0.Name = "textBox2_0";
            this.textBox2_0.ReadOnly = true;
            this.textBox2_0.Size = new System.Drawing.Size(18, 20);
            this.textBox2_0.TabIndex = 22;
            this.textBox2_0.Text = "1";
            this.textBox2_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal2
            // 
            this.labelVal2.AutoSize = true;
            this.labelVal2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal2.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal2.Location = new System.Drawing.Point(165, 23);
            this.labelVal2.Name = "labelVal2";
            this.labelVal2.Size = new System.Drawing.Size(39, 15);
            this.labelVal2.TabIndex = 7;
            this.labelVal2.Text = "3FFF";
            // 
            // labelAdr2
            // 
            this.labelAdr2.AutoSize = true;
            this.labelAdr2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr2.Location = new System.Drawing.Point(88, 23);
            this.labelAdr2.Name = "labelAdr2";
            this.labelAdr2.Size = new System.Drawing.Size(71, 15);
            this.labelAdr2.TabIndex = 1;
            this.labelAdr2.Text = "20080000";
            // 
            // textBox2_1
            // 
            this.textBox2_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_1.Location = new System.Drawing.Point(598, 22);
            this.textBox2_1.Name = "textBox2_1";
            this.textBox2_1.ReadOnly = true;
            this.textBox2_1.Size = new System.Drawing.Size(18, 20);
            this.textBox2_1.TabIndex = 21;
            this.textBox2_1.Text = "1";
            this.textBox2_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName2
            // 
            this.labelName2.AutoSize = true;
            this.labelName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName2.Location = new System.Drawing.Point(-3, 23);
            this.labelName2.Name = "labelName2";
            this.labelName2.Size = new System.Drawing.Size(66, 15);
            this.labelName2.TabIndex = 0;
            this.labelName2.Text = "CONFIG2";
            // 
            // textBox2_2
            // 
            this.textBox2_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_2.Location = new System.Drawing.Point(574, 22);
            this.textBox2_2.Name = "textBox2_2";
            this.textBox2_2.ReadOnly = true;
            this.textBox2_2.Size = new System.Drawing.Size(18, 20);
            this.textBox2_2.TabIndex = 20;
            this.textBox2_2.Text = "1";
            this.textBox2_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_11
            // 
            this.textBox2_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_11.Location = new System.Drawing.Point(341, 22);
            this.textBox2_11.Name = "textBox2_11";
            this.textBox2_11.ReadOnly = true;
            this.textBox2_11.Size = new System.Drawing.Size(18, 20);
            this.textBox2_11.TabIndex = 11;
            this.textBox2_11.Text = "1";
            this.textBox2_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_12
            // 
            this.textBox2_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_12.Location = new System.Drawing.Point(309, 22);
            this.textBox2_12.Name = "textBox2_12";
            this.textBox2_12.ReadOnly = true;
            this.textBox2_12.Size = new System.Drawing.Size(18, 20);
            this.textBox2_12.TabIndex = 10;
            this.textBox2_12.Text = "1";
            this.textBox2_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_3
            // 
            this.textBox2_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_3.Location = new System.Drawing.Point(550, 22);
            this.textBox2_3.Name = "textBox2_3";
            this.textBox2_3.ReadOnly = true;
            this.textBox2_3.Size = new System.Drawing.Size(18, 20);
            this.textBox2_3.TabIndex = 19;
            this.textBox2_3.Text = "1";
            this.textBox2_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_10
            // 
            this.textBox2_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_10.Location = new System.Drawing.Point(365, 22);
            this.textBox2_10.Name = "textBox2_10";
            this.textBox2_10.ReadOnly = true;
            this.textBox2_10.Size = new System.Drawing.Size(18, 20);
            this.textBox2_10.TabIndex = 12;
            this.textBox2_10.Text = "1";
            this.textBox2_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_13
            // 
            this.textBox2_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_13.Location = new System.Drawing.Point(285, 22);
            this.textBox2_13.Name = "textBox2_13";
            this.textBox2_13.ReadOnly = true;
            this.textBox2_13.Size = new System.Drawing.Size(18, 20);
            this.textBox2_13.TabIndex = 9;
            this.textBox2_13.Text = "1";
            this.textBox2_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_4
            // 
            this.textBox2_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_4.Location = new System.Drawing.Point(518, 22);
            this.textBox2_4.Name = "textBox2_4";
            this.textBox2_4.ReadOnly = true;
            this.textBox2_4.Size = new System.Drawing.Size(18, 20);
            this.textBox2_4.TabIndex = 18;
            this.textBox2_4.Text = "1";
            this.textBox2_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_9
            // 
            this.textBox2_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_9.Location = new System.Drawing.Point(389, 22);
            this.textBox2_9.Name = "textBox2_9";
            this.textBox2_9.ReadOnly = true;
            this.textBox2_9.Size = new System.Drawing.Size(18, 20);
            this.textBox2_9.TabIndex = 13;
            this.textBox2_9.Text = "1";
            this.textBox2_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_14
            // 
            this.textBox2_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_14.Location = new System.Drawing.Point(261, 22);
            this.textBox2_14.Name = "textBox2_14";
            this.textBox2_14.ReadOnly = true;
            this.textBox2_14.Size = new System.Drawing.Size(18, 20);
            this.textBox2_14.TabIndex = 8;
            this.textBox2_14.Text = "1";
            this.textBox2_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_5
            // 
            this.textBox2_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_5.Location = new System.Drawing.Point(494, 22);
            this.textBox2_5.Name = "textBox2_5";
            this.textBox2_5.ReadOnly = true;
            this.textBox2_5.Size = new System.Drawing.Size(18, 20);
            this.textBox2_5.TabIndex = 17;
            this.textBox2_5.Text = "1";
            this.textBox2_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_8
            // 
            this.textBox2_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_8.Location = new System.Drawing.Point(413, 22);
            this.textBox2_8.Name = "textBox2_8";
            this.textBox2_8.ReadOnly = true;
            this.textBox2_8.Size = new System.Drawing.Size(18, 20);
            this.textBox2_8.TabIndex = 14;
            this.textBox2_8.Text = "1";
            this.textBox2_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_7
            // 
            this.textBox2_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_7.Location = new System.Drawing.Point(446, 22);
            this.textBox2_7.Name = "textBox2_7";
            this.textBox2_7.ReadOnly = true;
            this.textBox2_7.Size = new System.Drawing.Size(18, 20);
            this.textBox2_7.TabIndex = 15;
            this.textBox2_7.Text = "1";
            this.textBox2_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox2_6
            // 
            this.textBox2_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox2_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox2_6.Location = new System.Drawing.Point(470, 22);
            this.textBox2_6.Name = "textBox2_6";
            this.textBox2_6.ReadOnly = true;
            this.textBox2_6.Size = new System.Drawing.Size(18, 20);
            this.textBox2_6.TabIndex = 16;
            this.textBox2_6.Text = "1";
            this.textBox2_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox2_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label40
            // 
            this.label40.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(100, 523);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(317, 13);
            this.label40.TabIndex = 12;
            this.label40.Text = "Unimplemented bits are displayed in the Value column as selected";
            // 
            // label41
            // 
            this.label41.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(100, 536);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(44, 13);
            this.label41.TabIndex = 13;
            this.label41.Text = "in menu";
            // 
            // label42
            // 
            this.label42.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(142, 536);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(208, 13);
            this.label42.TabIndex = 14;
            this.label42.Text = "Tools > Display Unimplemented Config Bits";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.textBox3_15);
            this.panel3.Controls.Add(this.label43);
            this.panel3.Controls.Add(this.label44);
            this.panel3.Controls.Add(this.label45);
            this.panel3.Controls.Add(this.label46);
            this.panel3.Controls.Add(this.label47);
            this.panel3.Controls.Add(this.label48);
            this.panel3.Controls.Add(this.label49);
            this.panel3.Controls.Add(this.label50);
            this.panel3.Controls.Add(this.label51);
            this.panel3.Controls.Add(this.label52);
            this.panel3.Controls.Add(this.label53);
            this.panel3.Controls.Add(this.label54);
            this.panel3.Controls.Add(this.label55);
            this.panel3.Controls.Add(this.label56);
            this.panel3.Controls.Add(this.label57);
            this.panel3.Controls.Add(this.label58);
            this.panel3.Controls.Add(this.textBox3_0);
            this.panel3.Controls.Add(this.labelVal3);
            this.panel3.Controls.Add(this.labelAdr3);
            this.panel3.Controls.Add(this.textBox3_1);
            this.panel3.Controls.Add(this.labelName3);
            this.panel3.Controls.Add(this.textBox3_2);
            this.panel3.Controls.Add(this.textBox3_11);
            this.panel3.Controls.Add(this.textBox3_12);
            this.panel3.Controls.Add(this.textBox3_3);
            this.panel3.Controls.Add(this.textBox3_10);
            this.panel3.Controls.Add(this.textBox3_13);
            this.panel3.Controls.Add(this.textBox3_4);
            this.panel3.Controls.Add(this.textBox3_9);
            this.panel3.Controls.Add(this.textBox3_14);
            this.panel3.Controls.Add(this.textBox3_5);
            this.panel3.Controls.Add(this.textBox3_8);
            this.panel3.Controls.Add(this.textBox3_7);
            this.panel3.Controls.Add(this.textBox3_6);
            this.panel3.Location = new System.Drawing.Point(12, 173);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(648, 46);
            this.panel3.TabIndex = 15;
            // 
            // textBox3_15
            // 
            this.textBox3_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_15.Location = new System.Drawing.Point(237, 22);
            this.textBox3_15.Name = "textBox3_15";
            this.textBox3_15.ReadOnly = true;
            this.textBox3_15.Size = new System.Drawing.Size(18, 20);
            this.textBox3_15.TabIndex = 11;
            this.textBox3_15.Text = "1";
            this.textBox3_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(624, 6);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(13, 13);
            this.label43.TabIndex = 38;
            this.label43.Text = "0";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(600, 6);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(13, 13);
            this.label44.TabIndex = 37;
            this.label44.Text = "1";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(576, 6);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(13, 13);
            this.label45.TabIndex = 36;
            this.label45.Text = "2";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(552, 6);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(13, 13);
            this.label46.TabIndex = 35;
            this.label46.Text = "3";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(520, 6);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(13, 13);
            this.label47.TabIndex = 34;
            this.label47.Text = "4";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(496, 6);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(13, 13);
            this.label48.TabIndex = 33;
            this.label48.Text = "5";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(472, 6);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(13, 13);
            this.label49.TabIndex = 32;
            this.label49.Text = "6";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(448, 6);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(13, 13);
            this.label50.TabIndex = 31;
            this.label50.Text = "7";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(415, 6);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(13, 13);
            this.label51.TabIndex = 30;
            this.label51.Text = "8";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(391, 6);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(13, 13);
            this.label52.TabIndex = 29;
            this.label52.Text = "9";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(364, 6);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(19, 13);
            this.label53.TabIndex = 28;
            this.label53.Text = "10";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(340, 6);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(19, 13);
            this.label54.TabIndex = 27;
            this.label54.Text = "11";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(308, 6);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(19, 13);
            this.label55.TabIndex = 26;
            this.label55.Text = "12";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(284, 6);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(19, 13);
            this.label56.TabIndex = 25;
            this.label56.Text = "13";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(260, 6);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(19, 13);
            this.label57.TabIndex = 24;
            this.label57.Text = "14";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(236, 6);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(19, 13);
            this.label58.TabIndex = 23;
            this.label58.Text = "15";
            // 
            // textBox3_0
            // 
            this.textBox3_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_0.Location = new System.Drawing.Point(622, 22);
            this.textBox3_0.Name = "textBox3_0";
            this.textBox3_0.ReadOnly = true;
            this.textBox3_0.Size = new System.Drawing.Size(18, 20);
            this.textBox3_0.TabIndex = 22;
            this.textBox3_0.Text = "1";
            this.textBox3_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal3
            // 
            this.labelVal3.AutoSize = true;
            this.labelVal3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal3.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal3.Location = new System.Drawing.Point(165, 23);
            this.labelVal3.Name = "labelVal3";
            this.labelVal3.Size = new System.Drawing.Size(39, 15);
            this.labelVal3.TabIndex = 7;
            this.labelVal3.Text = "3FFF";
            // 
            // labelAdr3
            // 
            this.labelAdr3.AutoSize = true;
            this.labelAdr3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr3.Location = new System.Drawing.Point(88, 23);
            this.labelAdr3.Name = "labelAdr3";
            this.labelAdr3.Size = new System.Drawing.Size(71, 15);
            this.labelAdr3.TabIndex = 1;
            this.labelAdr3.Text = "20080000";
            // 
            // textBox3_1
            // 
            this.textBox3_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_1.Location = new System.Drawing.Point(598, 22);
            this.textBox3_1.Name = "textBox3_1";
            this.textBox3_1.ReadOnly = true;
            this.textBox3_1.Size = new System.Drawing.Size(18, 20);
            this.textBox3_1.TabIndex = 21;
            this.textBox3_1.Text = "1";
            this.textBox3_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName3
            // 
            this.labelName3.AutoSize = true;
            this.labelName3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName3.Location = new System.Drawing.Point(-3, 23);
            this.labelName3.Name = "labelName3";
            this.labelName3.Size = new System.Drawing.Size(73, 15);
            this.labelName3.TabIndex = 0;
            this.labelName3.Text = "FBORPOR";
            // 
            // textBox3_2
            // 
            this.textBox3_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_2.Location = new System.Drawing.Point(574, 22);
            this.textBox3_2.Name = "textBox3_2";
            this.textBox3_2.ReadOnly = true;
            this.textBox3_2.Size = new System.Drawing.Size(18, 20);
            this.textBox3_2.TabIndex = 20;
            this.textBox3_2.Text = "1";
            this.textBox3_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_11
            // 
            this.textBox3_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_11.Location = new System.Drawing.Point(341, 22);
            this.textBox3_11.Name = "textBox3_11";
            this.textBox3_11.ReadOnly = true;
            this.textBox3_11.Size = new System.Drawing.Size(18, 20);
            this.textBox3_11.TabIndex = 11;
            this.textBox3_11.Text = "1";
            this.textBox3_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_12
            // 
            this.textBox3_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_12.Location = new System.Drawing.Point(309, 22);
            this.textBox3_12.Name = "textBox3_12";
            this.textBox3_12.ReadOnly = true;
            this.textBox3_12.Size = new System.Drawing.Size(18, 20);
            this.textBox3_12.TabIndex = 10;
            this.textBox3_12.Text = "1";
            this.textBox3_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_3
            // 
            this.textBox3_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_3.Location = new System.Drawing.Point(550, 22);
            this.textBox3_3.Name = "textBox3_3";
            this.textBox3_3.ReadOnly = true;
            this.textBox3_3.Size = new System.Drawing.Size(18, 20);
            this.textBox3_3.TabIndex = 19;
            this.textBox3_3.Text = "1";
            this.textBox3_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_10
            // 
            this.textBox3_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_10.Location = new System.Drawing.Point(365, 22);
            this.textBox3_10.Name = "textBox3_10";
            this.textBox3_10.ReadOnly = true;
            this.textBox3_10.Size = new System.Drawing.Size(18, 20);
            this.textBox3_10.TabIndex = 12;
            this.textBox3_10.Text = "1";
            this.textBox3_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_13
            // 
            this.textBox3_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_13.Location = new System.Drawing.Point(285, 22);
            this.textBox3_13.Name = "textBox3_13";
            this.textBox3_13.ReadOnly = true;
            this.textBox3_13.Size = new System.Drawing.Size(18, 20);
            this.textBox3_13.TabIndex = 9;
            this.textBox3_13.Text = "1";
            this.textBox3_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_4
            // 
            this.textBox3_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_4.Location = new System.Drawing.Point(518, 22);
            this.textBox3_4.Name = "textBox3_4";
            this.textBox3_4.ReadOnly = true;
            this.textBox3_4.Size = new System.Drawing.Size(18, 20);
            this.textBox3_4.TabIndex = 18;
            this.textBox3_4.Text = "1";
            this.textBox3_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_9
            // 
            this.textBox3_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_9.Location = new System.Drawing.Point(389, 22);
            this.textBox3_9.Name = "textBox3_9";
            this.textBox3_9.ReadOnly = true;
            this.textBox3_9.Size = new System.Drawing.Size(18, 20);
            this.textBox3_9.TabIndex = 13;
            this.textBox3_9.Text = "1";
            this.textBox3_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_14
            // 
            this.textBox3_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_14.Location = new System.Drawing.Point(261, 22);
            this.textBox3_14.Name = "textBox3_14";
            this.textBox3_14.ReadOnly = true;
            this.textBox3_14.Size = new System.Drawing.Size(18, 20);
            this.textBox3_14.TabIndex = 8;
            this.textBox3_14.Text = "1";
            this.textBox3_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_5
            // 
            this.textBox3_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_5.Location = new System.Drawing.Point(494, 22);
            this.textBox3_5.Name = "textBox3_5";
            this.textBox3_5.ReadOnly = true;
            this.textBox3_5.Size = new System.Drawing.Size(18, 20);
            this.textBox3_5.TabIndex = 17;
            this.textBox3_5.Text = "1";
            this.textBox3_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_8
            // 
            this.textBox3_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_8.Location = new System.Drawing.Point(413, 22);
            this.textBox3_8.Name = "textBox3_8";
            this.textBox3_8.ReadOnly = true;
            this.textBox3_8.Size = new System.Drawing.Size(18, 20);
            this.textBox3_8.TabIndex = 14;
            this.textBox3_8.Text = "1";
            this.textBox3_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_7
            // 
            this.textBox3_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_7.Location = new System.Drawing.Point(446, 22);
            this.textBox3_7.Name = "textBox3_7";
            this.textBox3_7.ReadOnly = true;
            this.textBox3_7.Size = new System.Drawing.Size(18, 20);
            this.textBox3_7.TabIndex = 15;
            this.textBox3_7.Text = "1";
            this.textBox3_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox3_6
            // 
            this.textBox3_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox3_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox3_6.Location = new System.Drawing.Point(470, 22);
            this.textBox3_6.Name = "textBox3_6";
            this.textBox3_6.ReadOnly = true;
            this.textBox3_6.Size = new System.Drawing.Size(18, 20);
            this.textBox3_6.TabIndex = 16;
            this.textBox3_6.Text = "1";
            this.textBox3_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox3_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.textBox4_15);
            this.panel4.Controls.Add(this.label59);
            this.panel4.Controls.Add(this.label60);
            this.panel4.Controls.Add(this.label61);
            this.panel4.Controls.Add(this.label62);
            this.panel4.Controls.Add(this.label63);
            this.panel4.Controls.Add(this.label64);
            this.panel4.Controls.Add(this.label65);
            this.panel4.Controls.Add(this.label66);
            this.panel4.Controls.Add(this.label67);
            this.panel4.Controls.Add(this.label68);
            this.panel4.Controls.Add(this.label69);
            this.panel4.Controls.Add(this.label70);
            this.panel4.Controls.Add(this.label71);
            this.panel4.Controls.Add(this.label72);
            this.panel4.Controls.Add(this.label73);
            this.panel4.Controls.Add(this.label74);
            this.panel4.Controls.Add(this.textBox4_0);
            this.panel4.Controls.Add(this.labelVal4);
            this.panel4.Controls.Add(this.labelAdr4);
            this.panel4.Controls.Add(this.textBox4_1);
            this.panel4.Controls.Add(this.labelName4);
            this.panel4.Controls.Add(this.textBox4_2);
            this.panel4.Controls.Add(this.textBox4_11);
            this.panel4.Controls.Add(this.textBox4_12);
            this.panel4.Controls.Add(this.textBox4_3);
            this.panel4.Controls.Add(this.textBox4_10);
            this.panel4.Controls.Add(this.textBox4_13);
            this.panel4.Controls.Add(this.textBox4_4);
            this.panel4.Controls.Add(this.textBox4_9);
            this.panel4.Controls.Add(this.textBox4_14);
            this.panel4.Controls.Add(this.textBox4_5);
            this.panel4.Controls.Add(this.textBox4_8);
            this.panel4.Controls.Add(this.textBox4_7);
            this.panel4.Controls.Add(this.textBox4_6);
            this.panel4.Location = new System.Drawing.Point(12, 221);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(648, 46);
            this.panel4.TabIndex = 16;
            // 
            // textBox4_15
            // 
            this.textBox4_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_15.Location = new System.Drawing.Point(237, 22);
            this.textBox4_15.Name = "textBox4_15";
            this.textBox4_15.ReadOnly = true;
            this.textBox4_15.Size = new System.Drawing.Size(18, 20);
            this.textBox4_15.TabIndex = 11;
            this.textBox4_15.Text = "1";
            this.textBox4_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(624, 6);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(13, 13);
            this.label59.TabIndex = 38;
            this.label59.Text = "0";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(600, 6);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(13, 13);
            this.label60.TabIndex = 37;
            this.label60.Text = "1";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(576, 6);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(13, 13);
            this.label61.TabIndex = 36;
            this.label61.Text = "2";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(552, 6);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(13, 13);
            this.label62.TabIndex = 35;
            this.label62.Text = "3";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(520, 6);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(13, 13);
            this.label63.TabIndex = 34;
            this.label63.Text = "4";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(496, 6);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(13, 13);
            this.label64.TabIndex = 33;
            this.label64.Text = "5";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(472, 6);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(13, 13);
            this.label65.TabIndex = 32;
            this.label65.Text = "6";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(448, 6);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(13, 13);
            this.label66.TabIndex = 31;
            this.label66.Text = "7";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(415, 6);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(13, 13);
            this.label67.TabIndex = 30;
            this.label67.Text = "8";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(391, 6);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(13, 13);
            this.label68.TabIndex = 29;
            this.label68.Text = "9";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(364, 6);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(19, 13);
            this.label69.TabIndex = 28;
            this.label69.Text = "10";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(340, 6);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(19, 13);
            this.label70.TabIndex = 27;
            this.label70.Text = "11";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(308, 6);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(19, 13);
            this.label71.TabIndex = 26;
            this.label71.Text = "12";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(284, 6);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(19, 13);
            this.label72.TabIndex = 25;
            this.label72.Text = "13";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(260, 6);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(19, 13);
            this.label73.TabIndex = 24;
            this.label73.Text = "14";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(236, 6);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(19, 13);
            this.label74.TabIndex = 23;
            this.label74.Text = "15";
            // 
            // textBox4_0
            // 
            this.textBox4_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_0.Location = new System.Drawing.Point(622, 22);
            this.textBox4_0.Name = "textBox4_0";
            this.textBox4_0.ReadOnly = true;
            this.textBox4_0.Size = new System.Drawing.Size(18, 20);
            this.textBox4_0.TabIndex = 22;
            this.textBox4_0.Text = "1";
            this.textBox4_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal4
            // 
            this.labelVal4.AutoSize = true;
            this.labelVal4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal4.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal4.Location = new System.Drawing.Point(165, 23);
            this.labelVal4.Name = "labelVal4";
            this.labelVal4.Size = new System.Drawing.Size(39, 15);
            this.labelVal4.TabIndex = 7;
            this.labelVal4.Text = "3FFF";
            // 
            // labelAdr4
            // 
            this.labelAdr4.AutoSize = true;
            this.labelAdr4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr4.Location = new System.Drawing.Point(88, 23);
            this.labelAdr4.Name = "labelAdr4";
            this.labelAdr4.Size = new System.Drawing.Size(71, 15);
            this.labelAdr4.TabIndex = 1;
            this.labelAdr4.Text = "20080000";
            // 
            // textBox4_1
            // 
            this.textBox4_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_1.Location = new System.Drawing.Point(598, 22);
            this.textBox4_1.Name = "textBox4_1";
            this.textBox4_1.ReadOnly = true;
            this.textBox4_1.Size = new System.Drawing.Size(18, 20);
            this.textBox4_1.TabIndex = 21;
            this.textBox4_1.Text = "1";
            this.textBox4_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName4
            // 
            this.labelName4.AutoSize = true;
            this.labelName4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName4.Location = new System.Drawing.Point(-3, 23);
            this.labelName4.Name = "labelName4";
            this.labelName4.Size = new System.Drawing.Size(77, 15);
            this.labelName4.TabIndex = 0;
            this.labelName4.Text = "DEVCFG1L";
            // 
            // textBox4_2
            // 
            this.textBox4_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_2.Location = new System.Drawing.Point(574, 22);
            this.textBox4_2.Name = "textBox4_2";
            this.textBox4_2.ReadOnly = true;
            this.textBox4_2.Size = new System.Drawing.Size(18, 20);
            this.textBox4_2.TabIndex = 20;
            this.textBox4_2.Text = "1";
            this.textBox4_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_11
            // 
            this.textBox4_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_11.Location = new System.Drawing.Point(341, 22);
            this.textBox4_11.Name = "textBox4_11";
            this.textBox4_11.ReadOnly = true;
            this.textBox4_11.Size = new System.Drawing.Size(18, 20);
            this.textBox4_11.TabIndex = 11;
            this.textBox4_11.Text = "1";
            this.textBox4_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_12
            // 
            this.textBox4_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_12.Location = new System.Drawing.Point(309, 22);
            this.textBox4_12.Name = "textBox4_12";
            this.textBox4_12.ReadOnly = true;
            this.textBox4_12.Size = new System.Drawing.Size(18, 20);
            this.textBox4_12.TabIndex = 10;
            this.textBox4_12.Text = "1";
            this.textBox4_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_3
            // 
            this.textBox4_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_3.Location = new System.Drawing.Point(550, 22);
            this.textBox4_3.Name = "textBox4_3";
            this.textBox4_3.ReadOnly = true;
            this.textBox4_3.Size = new System.Drawing.Size(18, 20);
            this.textBox4_3.TabIndex = 19;
            this.textBox4_3.Text = "1";
            this.textBox4_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_10
            // 
            this.textBox4_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_10.Location = new System.Drawing.Point(365, 22);
            this.textBox4_10.Name = "textBox4_10";
            this.textBox4_10.ReadOnly = true;
            this.textBox4_10.Size = new System.Drawing.Size(18, 20);
            this.textBox4_10.TabIndex = 12;
            this.textBox4_10.Text = "1";
            this.textBox4_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_13
            // 
            this.textBox4_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_13.Location = new System.Drawing.Point(285, 22);
            this.textBox4_13.Name = "textBox4_13";
            this.textBox4_13.ReadOnly = true;
            this.textBox4_13.Size = new System.Drawing.Size(18, 20);
            this.textBox4_13.TabIndex = 9;
            this.textBox4_13.Text = "1";
            this.textBox4_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_4
            // 
            this.textBox4_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_4.Location = new System.Drawing.Point(518, 22);
            this.textBox4_4.Name = "textBox4_4";
            this.textBox4_4.ReadOnly = true;
            this.textBox4_4.Size = new System.Drawing.Size(18, 20);
            this.textBox4_4.TabIndex = 18;
            this.textBox4_4.Text = "1";
            this.textBox4_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_9
            // 
            this.textBox4_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_9.Location = new System.Drawing.Point(389, 22);
            this.textBox4_9.Name = "textBox4_9";
            this.textBox4_9.ReadOnly = true;
            this.textBox4_9.Size = new System.Drawing.Size(18, 20);
            this.textBox4_9.TabIndex = 13;
            this.textBox4_9.Text = "1";
            this.textBox4_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_14
            // 
            this.textBox4_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_14.Location = new System.Drawing.Point(261, 22);
            this.textBox4_14.Name = "textBox4_14";
            this.textBox4_14.ReadOnly = true;
            this.textBox4_14.Size = new System.Drawing.Size(18, 20);
            this.textBox4_14.TabIndex = 8;
            this.textBox4_14.Text = "1";
            this.textBox4_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_5
            // 
            this.textBox4_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_5.Location = new System.Drawing.Point(494, 22);
            this.textBox4_5.Name = "textBox4_5";
            this.textBox4_5.ReadOnly = true;
            this.textBox4_5.Size = new System.Drawing.Size(18, 20);
            this.textBox4_5.TabIndex = 17;
            this.textBox4_5.Text = "1";
            this.textBox4_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_8
            // 
            this.textBox4_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_8.Location = new System.Drawing.Point(413, 22);
            this.textBox4_8.Name = "textBox4_8";
            this.textBox4_8.ReadOnly = true;
            this.textBox4_8.Size = new System.Drawing.Size(18, 20);
            this.textBox4_8.TabIndex = 14;
            this.textBox4_8.Text = "1";
            this.textBox4_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_7
            // 
            this.textBox4_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_7.Location = new System.Drawing.Point(446, 22);
            this.textBox4_7.Name = "textBox4_7";
            this.textBox4_7.ReadOnly = true;
            this.textBox4_7.Size = new System.Drawing.Size(18, 20);
            this.textBox4_7.TabIndex = 15;
            this.textBox4_7.Text = "1";
            this.textBox4_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox4_6
            // 
            this.textBox4_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox4_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox4_6.Location = new System.Drawing.Point(470, 22);
            this.textBox4_6.Name = "textBox4_6";
            this.textBox4_6.ReadOnly = true;
            this.textBox4_6.Size = new System.Drawing.Size(18, 20);
            this.textBox4_6.TabIndex = 16;
            this.textBox4_6.Text = "1";
            this.textBox4_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox4_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.textBox5_15);
            this.panel5.Controls.Add(this.label75);
            this.panel5.Controls.Add(this.label76);
            this.panel5.Controls.Add(this.label77);
            this.panel5.Controls.Add(this.label78);
            this.panel5.Controls.Add(this.label79);
            this.panel5.Controls.Add(this.label80);
            this.panel5.Controls.Add(this.label81);
            this.panel5.Controls.Add(this.label82);
            this.panel5.Controls.Add(this.label83);
            this.panel5.Controls.Add(this.label84);
            this.panel5.Controls.Add(this.label85);
            this.panel5.Controls.Add(this.label86);
            this.panel5.Controls.Add(this.label87);
            this.panel5.Controls.Add(this.label88);
            this.panel5.Controls.Add(this.label89);
            this.panel5.Controls.Add(this.label90);
            this.panel5.Controls.Add(this.textBox5_0);
            this.panel5.Controls.Add(this.labelVal5);
            this.panel5.Controls.Add(this.labelAdr5);
            this.panel5.Controls.Add(this.textBox5_1);
            this.panel5.Controls.Add(this.labelName5);
            this.panel5.Controls.Add(this.textBox5_2);
            this.panel5.Controls.Add(this.textBox5_11);
            this.panel5.Controls.Add(this.textBox5_12);
            this.panel5.Controls.Add(this.textBox5_3);
            this.panel5.Controls.Add(this.textBox5_10);
            this.panel5.Controls.Add(this.textBox5_13);
            this.panel5.Controls.Add(this.textBox5_4);
            this.panel5.Controls.Add(this.textBox5_9);
            this.panel5.Controls.Add(this.textBox5_14);
            this.panel5.Controls.Add(this.textBox5_5);
            this.panel5.Controls.Add(this.textBox5_8);
            this.panel5.Controls.Add(this.textBox5_7);
            this.panel5.Controls.Add(this.textBox5_6);
            this.panel5.Location = new System.Drawing.Point(12, 269);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(648, 46);
            this.panel5.TabIndex = 17;
            // 
            // textBox5_15
            // 
            this.textBox5_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_15.Location = new System.Drawing.Point(237, 22);
            this.textBox5_15.Name = "textBox5_15";
            this.textBox5_15.ReadOnly = true;
            this.textBox5_15.Size = new System.Drawing.Size(18, 20);
            this.textBox5_15.TabIndex = 11;
            this.textBox5_15.Text = "1";
            this.textBox5_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(624, 6);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(13, 13);
            this.label75.TabIndex = 38;
            this.label75.Text = "0";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(600, 6);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(13, 13);
            this.label76.TabIndex = 37;
            this.label76.Text = "1";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(576, 6);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(13, 13);
            this.label77.TabIndex = 36;
            this.label77.Text = "2";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(552, 6);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(13, 13);
            this.label78.TabIndex = 35;
            this.label78.Text = "3";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(520, 6);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(13, 13);
            this.label79.TabIndex = 34;
            this.label79.Text = "4";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(496, 6);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(13, 13);
            this.label80.TabIndex = 33;
            this.label80.Text = "5";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(472, 6);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(13, 13);
            this.label81.TabIndex = 32;
            this.label81.Text = "6";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(448, 6);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(13, 13);
            this.label82.TabIndex = 31;
            this.label82.Text = "7";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(415, 6);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(13, 13);
            this.label83.TabIndex = 30;
            this.label83.Text = "8";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(391, 6);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(13, 13);
            this.label84.TabIndex = 29;
            this.label84.Text = "9";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(364, 6);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(19, 13);
            this.label85.TabIndex = 28;
            this.label85.Text = "10";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(340, 6);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(19, 13);
            this.label86.TabIndex = 27;
            this.label86.Text = "11";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(308, 6);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(19, 13);
            this.label87.TabIndex = 26;
            this.label87.Text = "12";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(284, 6);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(19, 13);
            this.label88.TabIndex = 25;
            this.label88.Text = "13";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(260, 6);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(19, 13);
            this.label89.TabIndex = 24;
            this.label89.Text = "14";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(236, 6);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(19, 13);
            this.label90.TabIndex = 23;
            this.label90.Text = "15";
            // 
            // textBox5_0
            // 
            this.textBox5_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_0.Location = new System.Drawing.Point(622, 22);
            this.textBox5_0.Name = "textBox5_0";
            this.textBox5_0.ReadOnly = true;
            this.textBox5_0.Size = new System.Drawing.Size(18, 20);
            this.textBox5_0.TabIndex = 22;
            this.textBox5_0.Text = "1";
            this.textBox5_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal5
            // 
            this.labelVal5.AutoSize = true;
            this.labelVal5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal5.Location = new System.Drawing.Point(165, 23);
            this.labelVal5.Name = "labelVal5";
            this.labelVal5.Size = new System.Drawing.Size(39, 15);
            this.labelVal5.TabIndex = 7;
            this.labelVal5.Text = "3FFF";
            // 
            // labelAdr5
            // 
            this.labelAdr5.AutoSize = true;
            this.labelAdr5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr5.Location = new System.Drawing.Point(88, 23);
            this.labelAdr5.Name = "labelAdr5";
            this.labelAdr5.Size = new System.Drawing.Size(71, 15);
            this.labelAdr5.TabIndex = 1;
            this.labelAdr5.Text = "20080000";
            // 
            // textBox5_1
            // 
            this.textBox5_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_1.Location = new System.Drawing.Point(598, 22);
            this.textBox5_1.Name = "textBox5_1";
            this.textBox5_1.ReadOnly = true;
            this.textBox5_1.Size = new System.Drawing.Size(18, 20);
            this.textBox5_1.TabIndex = 21;
            this.textBox5_1.Text = "1";
            this.textBox5_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName5
            // 
            this.labelName5.AutoSize = true;
            this.labelName5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName5.Location = new System.Drawing.Point(-3, 23);
            this.labelName5.Name = "labelName5";
            this.labelName5.Size = new System.Drawing.Size(33, 15);
            this.labelName5.TabIndex = 0;
            this.labelName5.Text = "FSS";
            // 
            // textBox5_2
            // 
            this.textBox5_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_2.Location = new System.Drawing.Point(574, 22);
            this.textBox5_2.Name = "textBox5_2";
            this.textBox5_2.ReadOnly = true;
            this.textBox5_2.Size = new System.Drawing.Size(18, 20);
            this.textBox5_2.TabIndex = 20;
            this.textBox5_2.Text = "1";
            this.textBox5_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_11
            // 
            this.textBox5_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_11.Location = new System.Drawing.Point(341, 22);
            this.textBox5_11.Name = "textBox5_11";
            this.textBox5_11.ReadOnly = true;
            this.textBox5_11.Size = new System.Drawing.Size(18, 20);
            this.textBox5_11.TabIndex = 11;
            this.textBox5_11.Text = "1";
            this.textBox5_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_12
            // 
            this.textBox5_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_12.Location = new System.Drawing.Point(309, 22);
            this.textBox5_12.Name = "textBox5_12";
            this.textBox5_12.ReadOnly = true;
            this.textBox5_12.Size = new System.Drawing.Size(18, 20);
            this.textBox5_12.TabIndex = 10;
            this.textBox5_12.Text = "1";
            this.textBox5_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_3
            // 
            this.textBox5_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_3.Location = new System.Drawing.Point(550, 22);
            this.textBox5_3.Name = "textBox5_3";
            this.textBox5_3.ReadOnly = true;
            this.textBox5_3.Size = new System.Drawing.Size(18, 20);
            this.textBox5_3.TabIndex = 19;
            this.textBox5_3.Text = "1";
            this.textBox5_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_10
            // 
            this.textBox5_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_10.Location = new System.Drawing.Point(365, 22);
            this.textBox5_10.Name = "textBox5_10";
            this.textBox5_10.ReadOnly = true;
            this.textBox5_10.Size = new System.Drawing.Size(18, 20);
            this.textBox5_10.TabIndex = 12;
            this.textBox5_10.Text = "1";
            this.textBox5_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_13
            // 
            this.textBox5_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_13.Location = new System.Drawing.Point(285, 22);
            this.textBox5_13.Name = "textBox5_13";
            this.textBox5_13.ReadOnly = true;
            this.textBox5_13.Size = new System.Drawing.Size(18, 20);
            this.textBox5_13.TabIndex = 9;
            this.textBox5_13.Text = "1";
            this.textBox5_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_4
            // 
            this.textBox5_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_4.Location = new System.Drawing.Point(518, 22);
            this.textBox5_4.Name = "textBox5_4";
            this.textBox5_4.ReadOnly = true;
            this.textBox5_4.Size = new System.Drawing.Size(18, 20);
            this.textBox5_4.TabIndex = 18;
            this.textBox5_4.Text = "1";
            this.textBox5_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_9
            // 
            this.textBox5_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_9.Location = new System.Drawing.Point(389, 22);
            this.textBox5_9.Name = "textBox5_9";
            this.textBox5_9.ReadOnly = true;
            this.textBox5_9.Size = new System.Drawing.Size(18, 20);
            this.textBox5_9.TabIndex = 13;
            this.textBox5_9.Text = "1";
            this.textBox5_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_14
            // 
            this.textBox5_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_14.Location = new System.Drawing.Point(261, 22);
            this.textBox5_14.Name = "textBox5_14";
            this.textBox5_14.ReadOnly = true;
            this.textBox5_14.Size = new System.Drawing.Size(18, 20);
            this.textBox5_14.TabIndex = 8;
            this.textBox5_14.Text = "1";
            this.textBox5_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_5
            // 
            this.textBox5_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_5.Location = new System.Drawing.Point(494, 22);
            this.textBox5_5.Name = "textBox5_5";
            this.textBox5_5.ReadOnly = true;
            this.textBox5_5.Size = new System.Drawing.Size(18, 20);
            this.textBox5_5.TabIndex = 17;
            this.textBox5_5.Text = "1";
            this.textBox5_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_8
            // 
            this.textBox5_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_8.Location = new System.Drawing.Point(413, 22);
            this.textBox5_8.Name = "textBox5_8";
            this.textBox5_8.ReadOnly = true;
            this.textBox5_8.Size = new System.Drawing.Size(18, 20);
            this.textBox5_8.TabIndex = 14;
            this.textBox5_8.Text = "1";
            this.textBox5_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_7
            // 
            this.textBox5_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_7.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox5_7.Location = new System.Drawing.Point(446, 22);
            this.textBox5_7.Name = "textBox5_7";
            this.textBox5_7.ReadOnly = true;
            this.textBox5_7.Size = new System.Drawing.Size(18, 20);
            this.textBox5_7.TabIndex = 15;
            this.textBox5_7.Text = "1";
            this.textBox5_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox5_6
            // 
            this.textBox5_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox5_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox5_6.Location = new System.Drawing.Point(470, 22);
            this.textBox5_6.Name = "textBox5_6";
            this.textBox5_6.ReadOnly = true;
            this.textBox5_6.Size = new System.Drawing.Size(18, 20);
            this.textBox5_6.TabIndex = 16;
            this.textBox5_6.Text = "1";
            this.textBox5_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox5_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.textBox6_15);
            this.panel6.Controls.Add(this.label91);
            this.panel6.Controls.Add(this.label92);
            this.panel6.Controls.Add(this.label93);
            this.panel6.Controls.Add(this.label94);
            this.panel6.Controls.Add(this.label95);
            this.panel6.Controls.Add(this.label96);
            this.panel6.Controls.Add(this.label97);
            this.panel6.Controls.Add(this.label98);
            this.panel6.Controls.Add(this.label99);
            this.panel6.Controls.Add(this.label100);
            this.panel6.Controls.Add(this.label101);
            this.panel6.Controls.Add(this.label102);
            this.panel6.Controls.Add(this.label103);
            this.panel6.Controls.Add(this.label104);
            this.panel6.Controls.Add(this.label105);
            this.panel6.Controls.Add(this.label106);
            this.panel6.Controls.Add(this.textBox6_0);
            this.panel6.Controls.Add(this.labelVal6);
            this.panel6.Controls.Add(this.labelAdr6);
            this.panel6.Controls.Add(this.textBox6_1);
            this.panel6.Controls.Add(this.labelName6);
            this.panel6.Controls.Add(this.textBox6_2);
            this.panel6.Controls.Add(this.textBox6_11);
            this.panel6.Controls.Add(this.textBox6_12);
            this.panel6.Controls.Add(this.textBox6_3);
            this.panel6.Controls.Add(this.textBox6_10);
            this.panel6.Controls.Add(this.textBox6_13);
            this.panel6.Controls.Add(this.textBox6_4);
            this.panel6.Controls.Add(this.textBox6_9);
            this.panel6.Controls.Add(this.textBox6_14);
            this.panel6.Controls.Add(this.textBox6_5);
            this.panel6.Controls.Add(this.textBox6_8);
            this.panel6.Controls.Add(this.textBox6_7);
            this.panel6.Controls.Add(this.textBox6_6);
            this.panel6.Location = new System.Drawing.Point(12, 317);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(648, 46);
            this.panel6.TabIndex = 18;
            // 
            // textBox6_15
            // 
            this.textBox6_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_15.Location = new System.Drawing.Point(237, 22);
            this.textBox6_15.Name = "textBox6_15";
            this.textBox6_15.ReadOnly = true;
            this.textBox6_15.Size = new System.Drawing.Size(18, 20);
            this.textBox6_15.TabIndex = 11;
            this.textBox6_15.Text = "1";
            this.textBox6_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(624, 6);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(13, 13);
            this.label91.TabIndex = 38;
            this.label91.Text = "0";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(600, 6);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(13, 13);
            this.label92.TabIndex = 37;
            this.label92.Text = "1";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(576, 6);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(13, 13);
            this.label93.TabIndex = 36;
            this.label93.Text = "2";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(552, 6);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(13, 13);
            this.label94.TabIndex = 35;
            this.label94.Text = "3";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(520, 6);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(13, 13);
            this.label95.TabIndex = 34;
            this.label95.Text = "4";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(496, 6);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(13, 13);
            this.label96.TabIndex = 33;
            this.label96.Text = "5";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(472, 6);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(13, 13);
            this.label97.TabIndex = 32;
            this.label97.Text = "6";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(448, 6);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(13, 13);
            this.label98.TabIndex = 31;
            this.label98.Text = "7";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(415, 6);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(13, 13);
            this.label99.TabIndex = 30;
            this.label99.Text = "8";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(391, 6);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(13, 13);
            this.label100.TabIndex = 29;
            this.label100.Text = "9";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(364, 6);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(19, 13);
            this.label101.TabIndex = 28;
            this.label101.Text = "10";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(340, 6);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(19, 13);
            this.label102.TabIndex = 27;
            this.label102.Text = "11";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(308, 6);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(19, 13);
            this.label103.TabIndex = 26;
            this.label103.Text = "12";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(284, 6);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(19, 13);
            this.label104.TabIndex = 25;
            this.label104.Text = "13";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(260, 6);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(19, 13);
            this.label105.TabIndex = 24;
            this.label105.Text = "14";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(236, 6);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(19, 13);
            this.label106.TabIndex = 23;
            this.label106.Text = "15";
            // 
            // textBox6_0
            // 
            this.textBox6_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_0.Location = new System.Drawing.Point(622, 22);
            this.textBox6_0.Name = "textBox6_0";
            this.textBox6_0.ReadOnly = true;
            this.textBox6_0.Size = new System.Drawing.Size(18, 20);
            this.textBox6_0.TabIndex = 22;
            this.textBox6_0.Text = "1";
            this.textBox6_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal6
            // 
            this.labelVal6.AutoSize = true;
            this.labelVal6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal6.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal6.Location = new System.Drawing.Point(165, 23);
            this.labelVal6.Name = "labelVal6";
            this.labelVal6.Size = new System.Drawing.Size(39, 15);
            this.labelVal6.TabIndex = 7;
            this.labelVal6.Text = "3FFF";
            // 
            // labelAdr6
            // 
            this.labelAdr6.AutoSize = true;
            this.labelAdr6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr6.Location = new System.Drawing.Point(88, 23);
            this.labelAdr6.Name = "labelAdr6";
            this.labelAdr6.Size = new System.Drawing.Size(71, 15);
            this.labelAdr6.TabIndex = 1;
            this.labelAdr6.Text = "20080000";
            // 
            // textBox6_1
            // 
            this.textBox6_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_1.Location = new System.Drawing.Point(598, 22);
            this.textBox6_1.Name = "textBox6_1";
            this.textBox6_1.ReadOnly = true;
            this.textBox6_1.Size = new System.Drawing.Size(18, 20);
            this.textBox6_1.TabIndex = 21;
            this.textBox6_1.Text = "1";
            this.textBox6_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName6
            // 
            this.labelName6.AutoSize = true;
            this.labelName6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName6.Location = new System.Drawing.Point(-3, 23);
            this.labelName6.Name = "labelName6";
            this.labelName6.Size = new System.Drawing.Size(66, 15);
            this.labelName6.TabIndex = 0;
            this.labelName6.Text = "CONFIG6";
            // 
            // textBox6_2
            // 
            this.textBox6_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_2.Location = new System.Drawing.Point(574, 22);
            this.textBox6_2.Name = "textBox6_2";
            this.textBox6_2.ReadOnly = true;
            this.textBox6_2.Size = new System.Drawing.Size(18, 20);
            this.textBox6_2.TabIndex = 20;
            this.textBox6_2.Text = "1";
            this.textBox6_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_11
            // 
            this.textBox6_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_11.Location = new System.Drawing.Point(341, 22);
            this.textBox6_11.Name = "textBox6_11";
            this.textBox6_11.ReadOnly = true;
            this.textBox6_11.Size = new System.Drawing.Size(18, 20);
            this.textBox6_11.TabIndex = 11;
            this.textBox6_11.Text = "1";
            this.textBox6_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_12
            // 
            this.textBox6_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_12.Location = new System.Drawing.Point(309, 22);
            this.textBox6_12.Name = "textBox6_12";
            this.textBox6_12.ReadOnly = true;
            this.textBox6_12.Size = new System.Drawing.Size(18, 20);
            this.textBox6_12.TabIndex = 10;
            this.textBox6_12.Text = "1";
            this.textBox6_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_3
            // 
            this.textBox6_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_3.Location = new System.Drawing.Point(550, 22);
            this.textBox6_3.Name = "textBox6_3";
            this.textBox6_3.ReadOnly = true;
            this.textBox6_3.Size = new System.Drawing.Size(18, 20);
            this.textBox6_3.TabIndex = 19;
            this.textBox6_3.Text = "1";
            this.textBox6_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_10
            // 
            this.textBox6_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_10.Location = new System.Drawing.Point(365, 22);
            this.textBox6_10.Name = "textBox6_10";
            this.textBox6_10.ReadOnly = true;
            this.textBox6_10.Size = new System.Drawing.Size(18, 20);
            this.textBox6_10.TabIndex = 12;
            this.textBox6_10.Text = "1";
            this.textBox6_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_13
            // 
            this.textBox6_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_13.Location = new System.Drawing.Point(285, 22);
            this.textBox6_13.Name = "textBox6_13";
            this.textBox6_13.ReadOnly = true;
            this.textBox6_13.Size = new System.Drawing.Size(18, 20);
            this.textBox6_13.TabIndex = 9;
            this.textBox6_13.Text = "1";
            this.textBox6_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_4
            // 
            this.textBox6_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_4.Location = new System.Drawing.Point(518, 22);
            this.textBox6_4.Name = "textBox6_4";
            this.textBox6_4.ReadOnly = true;
            this.textBox6_4.Size = new System.Drawing.Size(18, 20);
            this.textBox6_4.TabIndex = 18;
            this.textBox6_4.Text = "1";
            this.textBox6_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_9
            // 
            this.textBox6_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_9.Location = new System.Drawing.Point(389, 22);
            this.textBox6_9.Name = "textBox6_9";
            this.textBox6_9.ReadOnly = true;
            this.textBox6_9.Size = new System.Drawing.Size(18, 20);
            this.textBox6_9.TabIndex = 13;
            this.textBox6_9.Text = "1";
            this.textBox6_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_14
            // 
            this.textBox6_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_14.Location = new System.Drawing.Point(261, 22);
            this.textBox6_14.Name = "textBox6_14";
            this.textBox6_14.ReadOnly = true;
            this.textBox6_14.Size = new System.Drawing.Size(18, 20);
            this.textBox6_14.TabIndex = 8;
            this.textBox6_14.Text = "1";
            this.textBox6_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_5
            // 
            this.textBox6_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_5.Location = new System.Drawing.Point(494, 22);
            this.textBox6_5.Name = "textBox6_5";
            this.textBox6_5.ReadOnly = true;
            this.textBox6_5.Size = new System.Drawing.Size(18, 20);
            this.textBox6_5.TabIndex = 17;
            this.textBox6_5.Text = "1";
            this.textBox6_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_8
            // 
            this.textBox6_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_8.Location = new System.Drawing.Point(413, 22);
            this.textBox6_8.Name = "textBox6_8";
            this.textBox6_8.ReadOnly = true;
            this.textBox6_8.Size = new System.Drawing.Size(18, 20);
            this.textBox6_8.TabIndex = 14;
            this.textBox6_8.Text = "1";
            this.textBox6_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_7
            // 
            this.textBox6_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_7.Location = new System.Drawing.Point(446, 22);
            this.textBox6_7.Name = "textBox6_7";
            this.textBox6_7.ReadOnly = true;
            this.textBox6_7.Size = new System.Drawing.Size(18, 20);
            this.textBox6_7.TabIndex = 15;
            this.textBox6_7.Text = "1";
            this.textBox6_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox6_6
            // 
            this.textBox6_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox6_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox6_6.Location = new System.Drawing.Point(470, 22);
            this.textBox6_6.Name = "textBox6_6";
            this.textBox6_6.ReadOnly = true;
            this.textBox6_6.Size = new System.Drawing.Size(18, 20);
            this.textBox6_6.TabIndex = 16;
            this.textBox6_6.Text = "1";
            this.textBox6_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox6_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.textBox7_15);
            this.panel7.Controls.Add(this.label107);
            this.panel7.Controls.Add(this.label108);
            this.panel7.Controls.Add(this.label109);
            this.panel7.Controls.Add(this.label110);
            this.panel7.Controls.Add(this.label111);
            this.panel7.Controls.Add(this.label112);
            this.panel7.Controls.Add(this.label113);
            this.panel7.Controls.Add(this.label114);
            this.panel7.Controls.Add(this.label115);
            this.panel7.Controls.Add(this.label116);
            this.panel7.Controls.Add(this.label117);
            this.panel7.Controls.Add(this.label118);
            this.panel7.Controls.Add(this.label119);
            this.panel7.Controls.Add(this.label120);
            this.panel7.Controls.Add(this.label121);
            this.panel7.Controls.Add(this.label122);
            this.panel7.Controls.Add(this.textBox7_0);
            this.panel7.Controls.Add(this.labelVal7);
            this.panel7.Controls.Add(this.labelAdr7);
            this.panel7.Controls.Add(this.textBox7_1);
            this.panel7.Controls.Add(this.labelName7);
            this.panel7.Controls.Add(this.textBox7_2);
            this.panel7.Controls.Add(this.textBox7_11);
            this.panel7.Controls.Add(this.textBox7_12);
            this.panel7.Controls.Add(this.textBox7_3);
            this.panel7.Controls.Add(this.textBox7_10);
            this.panel7.Controls.Add(this.textBox7_13);
            this.panel7.Controls.Add(this.textBox7_4);
            this.panel7.Controls.Add(this.textBox7_9);
            this.panel7.Controls.Add(this.textBox7_14);
            this.panel7.Controls.Add(this.textBox7_5);
            this.panel7.Controls.Add(this.textBox7_8);
            this.panel7.Controls.Add(this.textBox7_7);
            this.panel7.Controls.Add(this.textBox7_6);
            this.panel7.Location = new System.Drawing.Point(12, 365);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(648, 46);
            this.panel7.TabIndex = 19;
            // 
            // textBox7_15
            // 
            this.textBox7_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_15.Location = new System.Drawing.Point(237, 22);
            this.textBox7_15.Name = "textBox7_15";
            this.textBox7_15.ReadOnly = true;
            this.textBox7_15.Size = new System.Drawing.Size(18, 20);
            this.textBox7_15.TabIndex = 11;
            this.textBox7_15.Text = "1";
            this.textBox7_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(624, 6);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(13, 13);
            this.label107.TabIndex = 38;
            this.label107.Text = "0";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(600, 6);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(13, 13);
            this.label108.TabIndex = 37;
            this.label108.Text = "1";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(576, 6);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(13, 13);
            this.label109.TabIndex = 36;
            this.label109.Text = "2";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(552, 6);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(13, 13);
            this.label110.TabIndex = 35;
            this.label110.Text = "3";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(520, 6);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(13, 13);
            this.label111.TabIndex = 34;
            this.label111.Text = "4";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(496, 6);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(13, 13);
            this.label112.TabIndex = 33;
            this.label112.Text = "5";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(472, 6);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(13, 13);
            this.label113.TabIndex = 32;
            this.label113.Text = "6";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(448, 6);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(13, 13);
            this.label114.TabIndex = 31;
            this.label114.Text = "7";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(415, 6);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(13, 13);
            this.label115.TabIndex = 30;
            this.label115.Text = "8";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(391, 6);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(13, 13);
            this.label116.TabIndex = 29;
            this.label116.Text = "9";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(364, 6);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(19, 13);
            this.label117.TabIndex = 28;
            this.label117.Text = "10";
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(340, 6);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(19, 13);
            this.label118.TabIndex = 27;
            this.label118.Text = "11";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(308, 6);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(19, 13);
            this.label119.TabIndex = 26;
            this.label119.Text = "12";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(284, 6);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(19, 13);
            this.label120.TabIndex = 25;
            this.label120.Text = "13";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(260, 6);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(19, 13);
            this.label121.TabIndex = 24;
            this.label121.Text = "14";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(236, 6);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(19, 13);
            this.label122.TabIndex = 23;
            this.label122.Text = "15";
            // 
            // textBox7_0
            // 
            this.textBox7_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_0.Location = new System.Drawing.Point(622, 22);
            this.textBox7_0.Name = "textBox7_0";
            this.textBox7_0.ReadOnly = true;
            this.textBox7_0.Size = new System.Drawing.Size(18, 20);
            this.textBox7_0.TabIndex = 22;
            this.textBox7_0.Text = "1";
            this.textBox7_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal7
            // 
            this.labelVal7.AutoSize = true;
            this.labelVal7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal7.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal7.Location = new System.Drawing.Point(165, 23);
            this.labelVal7.Name = "labelVal7";
            this.labelVal7.Size = new System.Drawing.Size(39, 15);
            this.labelVal7.TabIndex = 7;
            this.labelVal7.Text = "3FFF";
            // 
            // labelAdr7
            // 
            this.labelAdr7.AutoSize = true;
            this.labelAdr7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr7.Location = new System.Drawing.Point(88, 23);
            this.labelAdr7.Name = "labelAdr7";
            this.labelAdr7.Size = new System.Drawing.Size(71, 15);
            this.labelAdr7.TabIndex = 1;
            this.labelAdr7.Text = "20080000";
            // 
            // textBox7_1
            // 
            this.textBox7_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_1.Location = new System.Drawing.Point(598, 22);
            this.textBox7_1.Name = "textBox7_1";
            this.textBox7_1.ReadOnly = true;
            this.textBox7_1.Size = new System.Drawing.Size(18, 20);
            this.textBox7_1.TabIndex = 21;
            this.textBox7_1.Text = "1";
            this.textBox7_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName7
            // 
            this.labelName7.AutoSize = true;
            this.labelName7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName7.Location = new System.Drawing.Point(-3, 23);
            this.labelName7.Name = "labelName7";
            this.labelName7.Size = new System.Drawing.Size(66, 15);
            this.labelName7.TabIndex = 0;
            this.labelName7.Text = "CONFIG7";
            // 
            // textBox7_2
            // 
            this.textBox7_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_2.Location = new System.Drawing.Point(574, 22);
            this.textBox7_2.Name = "textBox7_2";
            this.textBox7_2.ReadOnly = true;
            this.textBox7_2.Size = new System.Drawing.Size(18, 20);
            this.textBox7_2.TabIndex = 20;
            this.textBox7_2.Text = "1";
            this.textBox7_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_11
            // 
            this.textBox7_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_11.Location = new System.Drawing.Point(341, 22);
            this.textBox7_11.Name = "textBox7_11";
            this.textBox7_11.ReadOnly = true;
            this.textBox7_11.Size = new System.Drawing.Size(18, 20);
            this.textBox7_11.TabIndex = 11;
            this.textBox7_11.Text = "1";
            this.textBox7_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_12
            // 
            this.textBox7_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_12.Location = new System.Drawing.Point(309, 22);
            this.textBox7_12.Name = "textBox7_12";
            this.textBox7_12.ReadOnly = true;
            this.textBox7_12.Size = new System.Drawing.Size(18, 20);
            this.textBox7_12.TabIndex = 10;
            this.textBox7_12.Text = "1";
            this.textBox7_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_3
            // 
            this.textBox7_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_3.Location = new System.Drawing.Point(550, 22);
            this.textBox7_3.Name = "textBox7_3";
            this.textBox7_3.ReadOnly = true;
            this.textBox7_3.Size = new System.Drawing.Size(18, 20);
            this.textBox7_3.TabIndex = 19;
            this.textBox7_3.Text = "1";
            this.textBox7_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_10
            // 
            this.textBox7_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_10.Location = new System.Drawing.Point(365, 22);
            this.textBox7_10.Name = "textBox7_10";
            this.textBox7_10.ReadOnly = true;
            this.textBox7_10.Size = new System.Drawing.Size(18, 20);
            this.textBox7_10.TabIndex = 12;
            this.textBox7_10.Text = "1";
            this.textBox7_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_13
            // 
            this.textBox7_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_13.Location = new System.Drawing.Point(285, 22);
            this.textBox7_13.Name = "textBox7_13";
            this.textBox7_13.ReadOnly = true;
            this.textBox7_13.Size = new System.Drawing.Size(18, 20);
            this.textBox7_13.TabIndex = 9;
            this.textBox7_13.Text = "1";
            this.textBox7_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_4
            // 
            this.textBox7_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_4.Location = new System.Drawing.Point(518, 22);
            this.textBox7_4.Name = "textBox7_4";
            this.textBox7_4.ReadOnly = true;
            this.textBox7_4.Size = new System.Drawing.Size(18, 20);
            this.textBox7_4.TabIndex = 18;
            this.textBox7_4.Text = "1";
            this.textBox7_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_9
            // 
            this.textBox7_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_9.Location = new System.Drawing.Point(389, 22);
            this.textBox7_9.Name = "textBox7_9";
            this.textBox7_9.ReadOnly = true;
            this.textBox7_9.Size = new System.Drawing.Size(18, 20);
            this.textBox7_9.TabIndex = 13;
            this.textBox7_9.Text = "1";
            this.textBox7_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_14
            // 
            this.textBox7_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_14.Location = new System.Drawing.Point(261, 22);
            this.textBox7_14.Name = "textBox7_14";
            this.textBox7_14.ReadOnly = true;
            this.textBox7_14.Size = new System.Drawing.Size(18, 20);
            this.textBox7_14.TabIndex = 8;
            this.textBox7_14.Text = "1";
            this.textBox7_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_5
            // 
            this.textBox7_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_5.Location = new System.Drawing.Point(494, 22);
            this.textBox7_5.Name = "textBox7_5";
            this.textBox7_5.ReadOnly = true;
            this.textBox7_5.Size = new System.Drawing.Size(18, 20);
            this.textBox7_5.TabIndex = 17;
            this.textBox7_5.Text = "1";
            this.textBox7_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_8
            // 
            this.textBox7_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_8.Location = new System.Drawing.Point(413, 22);
            this.textBox7_8.Name = "textBox7_8";
            this.textBox7_8.ReadOnly = true;
            this.textBox7_8.Size = new System.Drawing.Size(18, 20);
            this.textBox7_8.TabIndex = 14;
            this.textBox7_8.Text = "1";
            this.textBox7_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_7
            // 
            this.textBox7_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_7.Location = new System.Drawing.Point(446, 22);
            this.textBox7_7.Name = "textBox7_7";
            this.textBox7_7.ReadOnly = true;
            this.textBox7_7.Size = new System.Drawing.Size(18, 20);
            this.textBox7_7.TabIndex = 15;
            this.textBox7_7.Text = "1";
            this.textBox7_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox7_6
            // 
            this.textBox7_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox7_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox7_6.Location = new System.Drawing.Point(470, 22);
            this.textBox7_6.Name = "textBox7_6";
            this.textBox7_6.ReadOnly = true;
            this.textBox7_6.Size = new System.Drawing.Size(18, 20);
            this.textBox7_6.TabIndex = 16;
            this.textBox7_6.Text = "1";
            this.textBox7_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox7_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.textBox8_15);
            this.panel8.Controls.Add(this.label123);
            this.panel8.Controls.Add(this.label124);
            this.panel8.Controls.Add(this.label125);
            this.panel8.Controls.Add(this.label126);
            this.panel8.Controls.Add(this.label127);
            this.panel8.Controls.Add(this.label128);
            this.panel8.Controls.Add(this.label129);
            this.panel8.Controls.Add(this.label130);
            this.panel8.Controls.Add(this.label131);
            this.panel8.Controls.Add(this.label132);
            this.panel8.Controls.Add(this.label133);
            this.panel8.Controls.Add(this.label134);
            this.panel8.Controls.Add(this.label135);
            this.panel8.Controls.Add(this.label136);
            this.panel8.Controls.Add(this.label137);
            this.panel8.Controls.Add(this.label138);
            this.panel8.Controls.Add(this.textBox8_0);
            this.panel8.Controls.Add(this.labelVal8);
            this.panel8.Controls.Add(this.labelAdr8);
            this.panel8.Controls.Add(this.textBox8_1);
            this.panel8.Controls.Add(this.labelName8);
            this.panel8.Controls.Add(this.textBox8_2);
            this.panel8.Controls.Add(this.textBox8_11);
            this.panel8.Controls.Add(this.textBox8_12);
            this.panel8.Controls.Add(this.textBox8_3);
            this.panel8.Controls.Add(this.textBox8_10);
            this.panel8.Controls.Add(this.textBox8_13);
            this.panel8.Controls.Add(this.textBox8_4);
            this.panel8.Controls.Add(this.textBox8_9);
            this.panel8.Controls.Add(this.textBox8_14);
            this.panel8.Controls.Add(this.textBox8_5);
            this.panel8.Controls.Add(this.textBox8_8);
            this.panel8.Controls.Add(this.textBox8_7);
            this.panel8.Controls.Add(this.textBox8_6);
            this.panel8.Location = new System.Drawing.Point(12, 413);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(648, 46);
            this.panel8.TabIndex = 20;
            // 
            // textBox8_15
            // 
            this.textBox8_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_15.Location = new System.Drawing.Point(237, 22);
            this.textBox8_15.Name = "textBox8_15";
            this.textBox8_15.ReadOnly = true;
            this.textBox8_15.Size = new System.Drawing.Size(18, 20);
            this.textBox8_15.TabIndex = 11;
            this.textBox8_15.Text = "1";
            this.textBox8_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(624, 6);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(13, 13);
            this.label123.TabIndex = 38;
            this.label123.Text = "0";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(600, 6);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(13, 13);
            this.label124.TabIndex = 37;
            this.label124.Text = "1";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(576, 6);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(13, 13);
            this.label125.TabIndex = 36;
            this.label125.Text = "2";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(552, 6);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(13, 13);
            this.label126.TabIndex = 35;
            this.label126.Text = "3";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(520, 6);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(13, 13);
            this.label127.TabIndex = 34;
            this.label127.Text = "4";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(496, 6);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(13, 13);
            this.label128.TabIndex = 33;
            this.label128.Text = "5";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(472, 6);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(13, 13);
            this.label129.TabIndex = 32;
            this.label129.Text = "6";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(448, 6);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(13, 13);
            this.label130.TabIndex = 31;
            this.label130.Text = "7";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(415, 6);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(13, 13);
            this.label131.TabIndex = 30;
            this.label131.Text = "8";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(391, 6);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(13, 13);
            this.label132.TabIndex = 29;
            this.label132.Text = "9";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(364, 6);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(19, 13);
            this.label133.TabIndex = 28;
            this.label133.Text = "10";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(340, 6);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(19, 13);
            this.label134.TabIndex = 27;
            this.label134.Text = "11";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(308, 6);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(19, 13);
            this.label135.TabIndex = 26;
            this.label135.Text = "12";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(284, 6);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(19, 13);
            this.label136.TabIndex = 25;
            this.label136.Text = "13";
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(260, 6);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(19, 13);
            this.label137.TabIndex = 24;
            this.label137.Text = "14";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(236, 6);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(19, 13);
            this.label138.TabIndex = 23;
            this.label138.Text = "15";
            // 
            // textBox8_0
            // 
            this.textBox8_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_0.Location = new System.Drawing.Point(622, 22);
            this.textBox8_0.Name = "textBox8_0";
            this.textBox8_0.ReadOnly = true;
            this.textBox8_0.Size = new System.Drawing.Size(18, 20);
            this.textBox8_0.TabIndex = 22;
            this.textBox8_0.Text = "1";
            this.textBox8_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal8
            // 
            this.labelVal8.AutoSize = true;
            this.labelVal8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal8.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal8.Location = new System.Drawing.Point(165, 23);
            this.labelVal8.Name = "labelVal8";
            this.labelVal8.Size = new System.Drawing.Size(39, 15);
            this.labelVal8.TabIndex = 7;
            this.labelVal8.Text = "3FFF";
            // 
            // labelAdr8
            // 
            this.labelAdr8.AutoSize = true;
            this.labelAdr8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr8.Location = new System.Drawing.Point(88, 23);
            this.labelAdr8.Name = "labelAdr8";
            this.labelAdr8.Size = new System.Drawing.Size(71, 15);
            this.labelAdr8.TabIndex = 1;
            this.labelAdr8.Text = "20080000";
            // 
            // textBox8_1
            // 
            this.textBox8_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_1.Location = new System.Drawing.Point(598, 22);
            this.textBox8_1.Name = "textBox8_1";
            this.textBox8_1.ReadOnly = true;
            this.textBox8_1.Size = new System.Drawing.Size(18, 20);
            this.textBox8_1.TabIndex = 21;
            this.textBox8_1.Text = "1";
            this.textBox8_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName8
            // 
            this.labelName8.AutoSize = true;
            this.labelName8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName8.Location = new System.Drawing.Point(-3, 23);
            this.labelName8.Name = "labelName8";
            this.labelName8.Size = new System.Drawing.Size(38, 15);
            this.labelName8.TabIndex = 0;
            this.labelName8.Text = "FICD";
            // 
            // textBox8_2
            // 
            this.textBox8_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_2.Location = new System.Drawing.Point(574, 22);
            this.textBox8_2.Name = "textBox8_2";
            this.textBox8_2.ReadOnly = true;
            this.textBox8_2.Size = new System.Drawing.Size(18, 20);
            this.textBox8_2.TabIndex = 20;
            this.textBox8_2.Text = "1";
            this.textBox8_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_11
            // 
            this.textBox8_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_11.Location = new System.Drawing.Point(341, 22);
            this.textBox8_11.Name = "textBox8_11";
            this.textBox8_11.ReadOnly = true;
            this.textBox8_11.Size = new System.Drawing.Size(18, 20);
            this.textBox8_11.TabIndex = 11;
            this.textBox8_11.Text = "1";
            this.textBox8_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_12
            // 
            this.textBox8_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_12.Location = new System.Drawing.Point(309, 22);
            this.textBox8_12.Name = "textBox8_12";
            this.textBox8_12.ReadOnly = true;
            this.textBox8_12.Size = new System.Drawing.Size(18, 20);
            this.textBox8_12.TabIndex = 10;
            this.textBox8_12.Text = "1";
            this.textBox8_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_3
            // 
            this.textBox8_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_3.Location = new System.Drawing.Point(550, 22);
            this.textBox8_3.Name = "textBox8_3";
            this.textBox8_3.ReadOnly = true;
            this.textBox8_3.Size = new System.Drawing.Size(18, 20);
            this.textBox8_3.TabIndex = 19;
            this.textBox8_3.Text = "1";
            this.textBox8_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_10
            // 
            this.textBox8_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_10.Location = new System.Drawing.Point(365, 22);
            this.textBox8_10.Name = "textBox8_10";
            this.textBox8_10.ReadOnly = true;
            this.textBox8_10.Size = new System.Drawing.Size(18, 20);
            this.textBox8_10.TabIndex = 12;
            this.textBox8_10.Text = "1";
            this.textBox8_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_13
            // 
            this.textBox8_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_13.Location = new System.Drawing.Point(285, 22);
            this.textBox8_13.Name = "textBox8_13";
            this.textBox8_13.ReadOnly = true;
            this.textBox8_13.Size = new System.Drawing.Size(18, 20);
            this.textBox8_13.TabIndex = 9;
            this.textBox8_13.Text = "1";
            this.textBox8_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_4
            // 
            this.textBox8_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_4.Location = new System.Drawing.Point(518, 22);
            this.textBox8_4.Name = "textBox8_4";
            this.textBox8_4.ReadOnly = true;
            this.textBox8_4.Size = new System.Drawing.Size(18, 20);
            this.textBox8_4.TabIndex = 18;
            this.textBox8_4.Text = "1";
            this.textBox8_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_9
            // 
            this.textBox8_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_9.Location = new System.Drawing.Point(389, 22);
            this.textBox8_9.Name = "textBox8_9";
            this.textBox8_9.ReadOnly = true;
            this.textBox8_9.Size = new System.Drawing.Size(18, 20);
            this.textBox8_9.TabIndex = 13;
            this.textBox8_9.Text = "1";
            this.textBox8_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_14
            // 
            this.textBox8_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_14.Location = new System.Drawing.Point(261, 22);
            this.textBox8_14.Name = "textBox8_14";
            this.textBox8_14.ReadOnly = true;
            this.textBox8_14.Size = new System.Drawing.Size(18, 20);
            this.textBox8_14.TabIndex = 8;
            this.textBox8_14.Text = "1";
            this.textBox8_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_5
            // 
            this.textBox8_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_5.Location = new System.Drawing.Point(494, 22);
            this.textBox8_5.Name = "textBox8_5";
            this.textBox8_5.ReadOnly = true;
            this.textBox8_5.Size = new System.Drawing.Size(18, 20);
            this.textBox8_5.TabIndex = 17;
            this.textBox8_5.Text = "1";
            this.textBox8_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_8
            // 
            this.textBox8_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_8.Location = new System.Drawing.Point(413, 22);
            this.textBox8_8.Name = "textBox8_8";
            this.textBox8_8.ReadOnly = true;
            this.textBox8_8.Size = new System.Drawing.Size(18, 20);
            this.textBox8_8.TabIndex = 14;
            this.textBox8_8.Text = "1";
            this.textBox8_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_7
            // 
            this.textBox8_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_7.Location = new System.Drawing.Point(446, 22);
            this.textBox8_7.Name = "textBox8_7";
            this.textBox8_7.ReadOnly = true;
            this.textBox8_7.Size = new System.Drawing.Size(18, 20);
            this.textBox8_7.TabIndex = 15;
            this.textBox8_7.Text = "1";
            this.textBox8_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox8_6
            // 
            this.textBox8_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox8_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox8_6.Location = new System.Drawing.Point(470, 22);
            this.textBox8_6.Name = "textBox8_6";
            this.textBox8_6.ReadOnly = true;
            this.textBox8_6.Size = new System.Drawing.Size(18, 20);
            this.textBox8_6.TabIndex = 16;
            this.textBox8_6.Text = "1";
            this.textBox8_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox8_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.textBox9_15);
            this.panel9.Controls.Add(this.label139);
            this.panel9.Controls.Add(this.label140);
            this.panel9.Controls.Add(this.label141);
            this.panel9.Controls.Add(this.label142);
            this.panel9.Controls.Add(this.label143);
            this.panel9.Controls.Add(this.label144);
            this.panel9.Controls.Add(this.label145);
            this.panel9.Controls.Add(this.label146);
            this.panel9.Controls.Add(this.label147);
            this.panel9.Controls.Add(this.label148);
            this.panel9.Controls.Add(this.label149);
            this.panel9.Controls.Add(this.label150);
            this.panel9.Controls.Add(this.label151);
            this.panel9.Controls.Add(this.label152);
            this.panel9.Controls.Add(this.label153);
            this.panel9.Controls.Add(this.label154);
            this.panel9.Controls.Add(this.textBox9_0);
            this.panel9.Controls.Add(this.labelVal9);
            this.panel9.Controls.Add(this.labelAdr9);
            this.panel9.Controls.Add(this.textBox9_1);
            this.panel9.Controls.Add(this.labelName9);
            this.panel9.Controls.Add(this.textBox9_2);
            this.panel9.Controls.Add(this.textBox9_11);
            this.panel9.Controls.Add(this.textBox9_12);
            this.panel9.Controls.Add(this.textBox9_3);
            this.panel9.Controls.Add(this.textBox9_10);
            this.panel9.Controls.Add(this.textBox9_13);
            this.panel9.Controls.Add(this.textBox9_4);
            this.panel9.Controls.Add(this.textBox9_9);
            this.panel9.Controls.Add(this.textBox9_14);
            this.panel9.Controls.Add(this.textBox9_5);
            this.panel9.Controls.Add(this.textBox9_8);
            this.panel9.Controls.Add(this.textBox9_7);
            this.panel9.Controls.Add(this.textBox9_6);
            this.panel9.Location = new System.Drawing.Point(12, 461);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(648, 46);
            this.panel9.TabIndex = 21;
            // 
            // textBox9_15
            // 
            this.textBox9_15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_15.Location = new System.Drawing.Point(237, 22);
            this.textBox9_15.Name = "textBox9_15";
            this.textBox9_15.ReadOnly = true;
            this.textBox9_15.Size = new System.Drawing.Size(18, 20);
            this.textBox9_15.TabIndex = 11;
            this.textBox9_15.Text = "1";
            this.textBox9_15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_15.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(624, 6);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(13, 13);
            this.label139.TabIndex = 38;
            this.label139.Text = "0";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(600, 6);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(13, 13);
            this.label140.TabIndex = 37;
            this.label140.Text = "1";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(576, 6);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(13, 13);
            this.label141.TabIndex = 36;
            this.label141.Text = "2";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(552, 6);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(13, 13);
            this.label142.TabIndex = 35;
            this.label142.Text = "3";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(520, 6);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(13, 13);
            this.label143.TabIndex = 34;
            this.label143.Text = "4";
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(496, 6);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(13, 13);
            this.label144.TabIndex = 33;
            this.label144.Text = "5";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(472, 6);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(13, 13);
            this.label145.TabIndex = 32;
            this.label145.Text = "6";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(448, 6);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(13, 13);
            this.label146.TabIndex = 31;
            this.label146.Text = "7";
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Location = new System.Drawing.Point(415, 6);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(13, 13);
            this.label147.TabIndex = 30;
            this.label147.Text = "8";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.Location = new System.Drawing.Point(391, 6);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(13, 13);
            this.label148.TabIndex = 29;
            this.label148.Text = "9";
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(364, 6);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(19, 13);
            this.label149.TabIndex = 28;
            this.label149.Text = "10";
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(340, 6);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(19, 13);
            this.label150.TabIndex = 27;
            this.label150.Text = "11";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(308, 6);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(19, 13);
            this.label151.TabIndex = 26;
            this.label151.Text = "12";
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(284, 6);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(19, 13);
            this.label152.TabIndex = 25;
            this.label152.Text = "13";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(260, 6);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(19, 13);
            this.label153.TabIndex = 24;
            this.label153.Text = "14";
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(236, 6);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(19, 13);
            this.label154.TabIndex = 23;
            this.label154.Text = "15";
            // 
            // textBox9_0
            // 
            this.textBox9_0.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_0.Location = new System.Drawing.Point(622, 22);
            this.textBox9_0.Name = "textBox9_0";
            this.textBox9_0.ReadOnly = true;
            this.textBox9_0.Size = new System.Drawing.Size(18, 20);
            this.textBox9_0.TabIndex = 22;
            this.textBox9_0.Text = "1";
            this.textBox9_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_0.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelVal9
            // 
            this.labelVal9.AutoSize = true;
            this.labelVal9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVal9.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelVal9.Location = new System.Drawing.Point(165, 23);
            this.labelVal9.Name = "labelVal9";
            this.labelVal9.Size = new System.Drawing.Size(39, 15);
            this.labelVal9.TabIndex = 7;
            this.labelVal9.Text = "3FFF";
            // 
            // labelAdr9
            // 
            this.labelAdr9.AutoSize = true;
            this.labelAdr9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdr9.Location = new System.Drawing.Point(88, 23);
            this.labelAdr9.Name = "labelAdr9";
            this.labelAdr9.Size = new System.Drawing.Size(71, 15);
            this.labelAdr9.TabIndex = 1;
            this.labelAdr9.Text = "20080000";
            // 
            // textBox9_1
            // 
            this.textBox9_1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_1.Location = new System.Drawing.Point(598, 22);
            this.textBox9_1.Name = "textBox9_1";
            this.textBox9_1.ReadOnly = true;
            this.textBox9_1.Size = new System.Drawing.Size(18, 20);
            this.textBox9_1.TabIndex = 21;
            this.textBox9_1.Text = "1";
            this.textBox9_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_1.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // labelName9
            // 
            this.labelName9.AutoSize = true;
            this.labelName9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelName9.Location = new System.Drawing.Point(-3, 23);
            this.labelName9.Name = "labelName9";
            this.labelName9.Size = new System.Drawing.Size(34, 15);
            this.labelName9.TabIndex = 0;
            this.labelName9.Text = "FDS";
            // 
            // textBox9_2
            // 
            this.textBox9_2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_2.Location = new System.Drawing.Point(574, 22);
            this.textBox9_2.Name = "textBox9_2";
            this.textBox9_2.ReadOnly = true;
            this.textBox9_2.Size = new System.Drawing.Size(18, 20);
            this.textBox9_2.TabIndex = 20;
            this.textBox9_2.Text = "1";
            this.textBox9_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_2.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_11
            // 
            this.textBox9_11.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_11.Location = new System.Drawing.Point(341, 22);
            this.textBox9_11.Name = "textBox9_11";
            this.textBox9_11.ReadOnly = true;
            this.textBox9_11.Size = new System.Drawing.Size(18, 20);
            this.textBox9_11.TabIndex = 11;
            this.textBox9_11.Text = "1";
            this.textBox9_11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_11.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_12
            // 
            this.textBox9_12.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_12.Location = new System.Drawing.Point(309, 22);
            this.textBox9_12.Name = "textBox9_12";
            this.textBox9_12.ReadOnly = true;
            this.textBox9_12.Size = new System.Drawing.Size(18, 20);
            this.textBox9_12.TabIndex = 10;
            this.textBox9_12.Text = "1";
            this.textBox9_12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_12.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_3
            // 
            this.textBox9_3.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_3.Location = new System.Drawing.Point(550, 22);
            this.textBox9_3.Name = "textBox9_3";
            this.textBox9_3.ReadOnly = true;
            this.textBox9_3.Size = new System.Drawing.Size(18, 20);
            this.textBox9_3.TabIndex = 19;
            this.textBox9_3.Text = "1";
            this.textBox9_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_3.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_10
            // 
            this.textBox9_10.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_10.Location = new System.Drawing.Point(365, 22);
            this.textBox9_10.Name = "textBox9_10";
            this.textBox9_10.ReadOnly = true;
            this.textBox9_10.Size = new System.Drawing.Size(18, 20);
            this.textBox9_10.TabIndex = 12;
            this.textBox9_10.Text = "1";
            this.textBox9_10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_10.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_13
            // 
            this.textBox9_13.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_13.Location = new System.Drawing.Point(285, 22);
            this.textBox9_13.Name = "textBox9_13";
            this.textBox9_13.ReadOnly = true;
            this.textBox9_13.Size = new System.Drawing.Size(18, 20);
            this.textBox9_13.TabIndex = 9;
            this.textBox9_13.Text = "1";
            this.textBox9_13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_13.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_4
            // 
            this.textBox9_4.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_4.Location = new System.Drawing.Point(518, 22);
            this.textBox9_4.Name = "textBox9_4";
            this.textBox9_4.ReadOnly = true;
            this.textBox9_4.Size = new System.Drawing.Size(18, 20);
            this.textBox9_4.TabIndex = 18;
            this.textBox9_4.Text = "1";
            this.textBox9_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_4.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_9
            // 
            this.textBox9_9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_9.Location = new System.Drawing.Point(389, 22);
            this.textBox9_9.Name = "textBox9_9";
            this.textBox9_9.ReadOnly = true;
            this.textBox9_9.Size = new System.Drawing.Size(18, 20);
            this.textBox9_9.TabIndex = 13;
            this.textBox9_9.Text = "1";
            this.textBox9_9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_9.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_14
            // 
            this.textBox9_14.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_14.Location = new System.Drawing.Point(261, 22);
            this.textBox9_14.Name = "textBox9_14";
            this.textBox9_14.ReadOnly = true;
            this.textBox9_14.Size = new System.Drawing.Size(18, 20);
            this.textBox9_14.TabIndex = 8;
            this.textBox9_14.Text = "1";
            this.textBox9_14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_14.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_5
            // 
            this.textBox9_5.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_5.Location = new System.Drawing.Point(494, 22);
            this.textBox9_5.Name = "textBox9_5";
            this.textBox9_5.ReadOnly = true;
            this.textBox9_5.Size = new System.Drawing.Size(18, 20);
            this.textBox9_5.TabIndex = 17;
            this.textBox9_5.Text = "1";
            this.textBox9_5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_5.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_8
            // 
            this.textBox9_8.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_8.Location = new System.Drawing.Point(413, 22);
            this.textBox9_8.Name = "textBox9_8";
            this.textBox9_8.ReadOnly = true;
            this.textBox9_8.Size = new System.Drawing.Size(18, 20);
            this.textBox9_8.TabIndex = 14;
            this.textBox9_8.Text = "1";
            this.textBox9_8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_8.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_7
            // 
            this.textBox9_7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_7.Location = new System.Drawing.Point(446, 22);
            this.textBox9_7.Name = "textBox9_7";
            this.textBox9_7.ReadOnly = true;
            this.textBox9_7.Size = new System.Drawing.Size(18, 20);
            this.textBox9_7.TabIndex = 15;
            this.textBox9_7.Text = "1";
            this.textBox9_7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_7.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // textBox9_6
            // 
            this.textBox9_6.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox9_6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox9_6.Location = new System.Drawing.Point(470, 22);
            this.textBox9_6.Name = "textBox9_6";
            this.textBox9_6.ReadOnly = true;
            this.textBox9_6.Size = new System.Drawing.Size(18, 20);
            this.textBox9_6.TabIndex = 16;
            this.textBox9_6.Text = "1";
            this.textBox9_6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox9_6.Click += new System.EventHandler(this.textBox1_15_Click);
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label155.Location = new System.Drawing.Point(175, 28);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(13, 13);
            this.label155.TabIndex = 22;
            this.label155.Text = "1";
            // 
            // DialogConfigEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 558);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxUnimpl);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label155);
            this.Controls.Add(this.textBoxEx);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DialogConfigEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Configuration Word Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DialogConfigEdit_FormClosing);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelName1;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1_12;
        private System.Windows.Forms.TextBox textBox1_13;
        private System.Windows.Forms.TextBox textBox1_14;
        private System.Windows.Forms.TextBox textBoxEx;
        private System.Windows.Forms.Label labelVal1;
        private System.Windows.Forms.Label labelAdr1;
        private System.Windows.Forms.TextBox textBox1_0;
        private System.Windows.Forms.TextBox textBox1_1;
        private System.Windows.Forms.TextBox textBox1_2;
        private System.Windows.Forms.TextBox textBox1_11;
        private System.Windows.Forms.TextBox textBox1_3;
        private System.Windows.Forms.TextBox textBox1_10;
        private System.Windows.Forms.TextBox textBox1_4;
        private System.Windows.Forms.TextBox textBox1_9;
        private System.Windows.Forms.TextBox textBox1_5;
        private System.Windows.Forms.TextBox textBox1_8;
        private System.Windows.Forms.TextBox textBox1_7;
        private System.Windows.Forms.TextBox textBox1_6;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxUnimpl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1_15;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox2_15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox textBox2_0;
        private System.Windows.Forms.Label labelVal2;
        private System.Windows.Forms.Label labelAdr2;
        private System.Windows.Forms.TextBox textBox2_1;
        private System.Windows.Forms.Label labelName2;
        private System.Windows.Forms.TextBox textBox2_2;
        private System.Windows.Forms.TextBox textBox2_11;
        private System.Windows.Forms.TextBox textBox2_12;
        private System.Windows.Forms.TextBox textBox2_3;
        private System.Windows.Forms.TextBox textBox2_10;
        private System.Windows.Forms.TextBox textBox2_13;
        private System.Windows.Forms.TextBox textBox2_4;
        private System.Windows.Forms.TextBox textBox2_9;
        private System.Windows.Forms.TextBox textBox2_14;
        private System.Windows.Forms.TextBox textBox2_5;
        private System.Windows.Forms.TextBox textBox2_8;
        private System.Windows.Forms.TextBox textBox2_7;
        private System.Windows.Forms.TextBox textBox2_6;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox3_15;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox textBox3_0;
        private System.Windows.Forms.Label labelVal3;
        private System.Windows.Forms.Label labelAdr3;
        private System.Windows.Forms.TextBox textBox3_1;
        private System.Windows.Forms.Label labelName3;
        private System.Windows.Forms.TextBox textBox3_2;
        private System.Windows.Forms.TextBox textBox3_11;
        private System.Windows.Forms.TextBox textBox3_12;
        private System.Windows.Forms.TextBox textBox3_3;
        private System.Windows.Forms.TextBox textBox3_10;
        private System.Windows.Forms.TextBox textBox3_13;
        private System.Windows.Forms.TextBox textBox3_4;
        private System.Windows.Forms.TextBox textBox3_9;
        private System.Windows.Forms.TextBox textBox3_14;
        private System.Windows.Forms.TextBox textBox3_5;
        private System.Windows.Forms.TextBox textBox3_8;
        private System.Windows.Forms.TextBox textBox3_7;
        private System.Windows.Forms.TextBox textBox3_6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox textBox4_15;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.TextBox textBox4_0;
        private System.Windows.Forms.Label labelVal4;
        private System.Windows.Forms.Label labelAdr4;
        private System.Windows.Forms.TextBox textBox4_1;
        private System.Windows.Forms.Label labelName4;
        private System.Windows.Forms.TextBox textBox4_2;
        private System.Windows.Forms.TextBox textBox4_11;
        private System.Windows.Forms.TextBox textBox4_12;
        private System.Windows.Forms.TextBox textBox4_3;
        private System.Windows.Forms.TextBox textBox4_10;
        private System.Windows.Forms.TextBox textBox4_13;
        private System.Windows.Forms.TextBox textBox4_4;
        private System.Windows.Forms.TextBox textBox4_9;
        private System.Windows.Forms.TextBox textBox4_14;
        private System.Windows.Forms.TextBox textBox4_5;
        private System.Windows.Forms.TextBox textBox4_8;
        private System.Windows.Forms.TextBox textBox4_7;
        private System.Windows.Forms.TextBox textBox4_6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox textBox5_15;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.TextBox textBox5_0;
        private System.Windows.Forms.Label labelVal5;
        private System.Windows.Forms.Label labelAdr5;
        private System.Windows.Forms.TextBox textBox5_1;
        private System.Windows.Forms.Label labelName5;
        private System.Windows.Forms.TextBox textBox5_2;
        private System.Windows.Forms.TextBox textBox5_11;
        private System.Windows.Forms.TextBox textBox5_12;
        private System.Windows.Forms.TextBox textBox5_3;
        private System.Windows.Forms.TextBox textBox5_10;
        private System.Windows.Forms.TextBox textBox5_13;
        private System.Windows.Forms.TextBox textBox5_4;
        private System.Windows.Forms.TextBox textBox5_9;
        private System.Windows.Forms.TextBox textBox5_14;
        private System.Windows.Forms.TextBox textBox5_5;
        private System.Windows.Forms.TextBox textBox5_8;
        private System.Windows.Forms.TextBox textBox5_7;
        private System.Windows.Forms.TextBox textBox5_6;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox6_15;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.TextBox textBox6_0;
        private System.Windows.Forms.Label labelVal6;
        private System.Windows.Forms.Label labelAdr6;
        private System.Windows.Forms.TextBox textBox6_1;
        private System.Windows.Forms.Label labelName6;
        private System.Windows.Forms.TextBox textBox6_2;
        private System.Windows.Forms.TextBox textBox6_11;
        private System.Windows.Forms.TextBox textBox6_12;
        private System.Windows.Forms.TextBox textBox6_3;
        private System.Windows.Forms.TextBox textBox6_10;
        private System.Windows.Forms.TextBox textBox6_13;
        private System.Windows.Forms.TextBox textBox6_4;
        private System.Windows.Forms.TextBox textBox6_9;
        private System.Windows.Forms.TextBox textBox6_14;
        private System.Windows.Forms.TextBox textBox6_5;
        private System.Windows.Forms.TextBox textBox6_8;
        private System.Windows.Forms.TextBox textBox6_7;
        private System.Windows.Forms.TextBox textBox6_6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox7_15;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.TextBox textBox7_0;
        private System.Windows.Forms.Label labelVal7;
        private System.Windows.Forms.Label labelAdr7;
        private System.Windows.Forms.TextBox textBox7_1;
        private System.Windows.Forms.Label labelName7;
        private System.Windows.Forms.TextBox textBox7_2;
        private System.Windows.Forms.TextBox textBox7_11;
        private System.Windows.Forms.TextBox textBox7_12;
        private System.Windows.Forms.TextBox textBox7_3;
        private System.Windows.Forms.TextBox textBox7_10;
        private System.Windows.Forms.TextBox textBox7_13;
        private System.Windows.Forms.TextBox textBox7_4;
        private System.Windows.Forms.TextBox textBox7_9;
        private System.Windows.Forms.TextBox textBox7_14;
        private System.Windows.Forms.TextBox textBox7_5;
        private System.Windows.Forms.TextBox textBox7_8;
        private System.Windows.Forms.TextBox textBox7_7;
        private System.Windows.Forms.TextBox textBox7_6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBox8_15;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.TextBox textBox8_0;
        private System.Windows.Forms.Label labelVal8;
        private System.Windows.Forms.Label labelAdr8;
        private System.Windows.Forms.TextBox textBox8_1;
        private System.Windows.Forms.Label labelName8;
        private System.Windows.Forms.TextBox textBox8_2;
        private System.Windows.Forms.TextBox textBox8_11;
        private System.Windows.Forms.TextBox textBox8_12;
        private System.Windows.Forms.TextBox textBox8_3;
        private System.Windows.Forms.TextBox textBox8_10;
        private System.Windows.Forms.TextBox textBox8_13;
        private System.Windows.Forms.TextBox textBox8_4;
        private System.Windows.Forms.TextBox textBox8_9;
        private System.Windows.Forms.TextBox textBox8_14;
        private System.Windows.Forms.TextBox textBox8_5;
        private System.Windows.Forms.TextBox textBox8_8;
        private System.Windows.Forms.TextBox textBox8_7;
        private System.Windows.Forms.TextBox textBox8_6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox textBox9_15;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.TextBox textBox9_0;
        private System.Windows.Forms.Label labelVal9;
        private System.Windows.Forms.Label labelAdr9;
        private System.Windows.Forms.TextBox textBox9_1;
        private System.Windows.Forms.Label labelName9;
        private System.Windows.Forms.TextBox textBox9_2;
        private System.Windows.Forms.TextBox textBox9_11;
        private System.Windows.Forms.TextBox textBox9_12;
        private System.Windows.Forms.TextBox textBox9_3;
        private System.Windows.Forms.TextBox textBox9_10;
        private System.Windows.Forms.TextBox textBox9_13;
        private System.Windows.Forms.TextBox textBox9_4;
        private System.Windows.Forms.TextBox textBox9_9;
        private System.Windows.Forms.TextBox textBox9_14;
        private System.Windows.Forms.TextBox textBox9_5;
        private System.Windows.Forms.TextBox textBox9_8;
        private System.Windows.Forms.TextBox textBox9_7;
        private System.Windows.Forms.TextBox textBox9_6;
        private System.Windows.Forms.Label label155;
    }
}